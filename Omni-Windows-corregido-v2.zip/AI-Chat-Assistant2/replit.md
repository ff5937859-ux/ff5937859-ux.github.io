# Omni

A professional AI chat platform powered by OpenAI — dark-mode first, with real-time streaming responses, conversation history, favorites, search, and Clerk authentication.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/chat-app run dev` — run the frontend (port 18228)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite (artifacts/chat-app), Tailwind CSS, Framer Motion
- API: Express 5 (artifacts/api-server)
- Auth: Clerk (via Replit-managed tenant)
- AI: OpenAI via Replit AI Integrations (gpt-5.4 streaming)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (zod/v4), drizzle-zod
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — source of truth for API contracts
- `lib/db/src/schema/` — Drizzle DB schema (conversations.ts, messages.ts)
- `artifacts/api-server/src/routes/openai/` — chat, messages, images routes
- `artifacts/chat-app/src/` — React frontend
- `lib/integrations-openai-ai-server/` — OpenAI server SDK wrapper
- `lib/integrations-openai-ai-react/` — OpenAI React hooks

## Architecture decisions

- SSE streaming for AI responses: `sendOpenaiMessage` endpoint returns `text/event-stream`, client uses raw fetch + ReadableStream (Orval hooks can't handle SSE)
- Clerk auth is cookie-based on web — no bearer tokens needed for browser requests
- Conversations are created automatically when user sends their first message
- All conversations are scoped globally (no userId column) for simplicity in the first build
- OpenAI integration uses Replit AI Integrations proxy — no user API key required

## Product

- Real-time AI chat with token-level streaming responses
- Conversation history sidebar with search and favorites
- Markdown + code syntax highlighting in AI responses
- Copy and regenerate message actions
- Settings page for model/profile configuration
- Sign in / Sign up via Clerk (email + Google/GitHub)
- Dark mode with glassmorphism design

## User preferences

- Dark-mode-first UI with electric blue accent color
- Streaming responses displayed token-by-token
- Professional ChatGPT-style layout

## Gotchas

- Always re-run codegen after changing openapi.yaml: `pnpm --filter @workspace/api-spec run codegen`
- The SSE streaming endpoint cannot use generated Orval hooks — use raw fetch with ReadableStream
- Clerk proxy middleware must be mounted BEFORE express.json() in app.ts
- `tailwindcss({ optimize: false })` is required in vite.config.ts for Clerk themes to work in prod

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
