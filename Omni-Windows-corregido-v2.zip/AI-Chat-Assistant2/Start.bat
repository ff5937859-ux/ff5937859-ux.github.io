@echo off
setlocal
title StartBat - Omni
cd /d "%~dp0"
echo ==== StartBat: Omni ====

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js no esta instalado. Instala Node.js 22 LTS desde https://nodejs.org
  start https://nodejs.org
  pause
  exit /b 1
)
where pnpm >nul 2>nul
if errorlevel 1 (
  echo Instalando pnpm...
  call npm install -g pnpm
  if errorlevel 1 (echo No se pudo instalar pnpm.& pause & exit /b 1)
)
if not exist .env (
  if exist .env.example (copy .env.example .env >nul) else (echo Falta .env.example.& pause & exit /b 1)
  echo Se ha creado .env. Rellena las claves y vuelve a ejecutar Start.bat.
  start notepad .env
  pause
  exit /b 0
)

for /f "usebackq eol=# tokens=1,* delims==" %%a in (".env") do set "%%a=%%b"
if "%VITE_CLERK_PUBLISHABLE_KEY%"=="" goto :faltan
if "%CLERK_SECRET_KEY%"=="" goto :faltan
if "%OPENAI_API_KEY%"=="" goto :faltan
goto :deps
:faltan
echo Faltan claves necesarias en .env.
start notepad .env
pause
exit /b 1

:deps
echo Comprobando e instalando dependencias para Windows...
call pnpm install --force
if errorlevel 1 (echo Error instalando dependencias. Revisa la conexion y Node.js 22 LTS.& pause & exit /b 1)

echo Arrancando servidor API (puerto 8080) y web (puerto 3000)...
start "Omni API" cmd /k "set NODE_ENV=development&& set PORT=8080&& pnpm --filter @workspace/api-server run dev"
start "Omni Web" cmd /k "set PORT=3000&& set BASE_PATH=/&& pnpm --filter @workspace/chat-app run dev"
timeout /t 10 >nul
start http://localhost:3000
echo Omni se esta iniciando. Revisa las ventanas API y Web por si muestran errores.
pause
