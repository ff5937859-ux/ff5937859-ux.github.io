import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const votes = pgTable("wc_votes", {
  id: serial("id").primaryKey(),
  matchId: text("match_id").notNull(),
  teamId: text("team_id").notNull(),
  voterToken: text("voter_token").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Vote = typeof votes.$inferSelect;
