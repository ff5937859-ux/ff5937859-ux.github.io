# Chat IA Halloween Replacement — Design

## Goal and scope

Replace the FIFA World Cup 2026 feature inside the existing Chat IA app with a Halloween experience. This is a change to the current app, not a separate artifact. Do not add dependencies.

Remove the World Cup page, intro, navigation entries, API router, route registration, World Cup image assets, and all active application references to `FOOTBALL_DATA_API_KEY` and football-data.org. Preserve the existing `wc_votes` table and its records; do not migrate, rename, or delete it.

Keep Clerk authentication and its routes, the chat, conversation history, settings, streaming, and the splash-screen duration and behavior unchanged. Login and chat receive only non-interactive Halloween decoration.

## Navigation and introduction

- Add a protected `/halloween` route.
- Replace the three World Cup sidebar entries with one “Halloween 2026” pumpkin entry in orange and purple, with a subtle glow and gentle sway/flicker. Place it in the footer position and the corresponding collapsed-sidebar position, above Settings when collapsed. Show an active state when the route is `/halloween`. Do not add a second entry beside the Chat IA logo.
- Clicking the entry opens a full-screen overlay at `z-[9998]` with fade transitions; Skip and completion both navigate to `/halloween`. Direct navigation to `/halloween` does not replay the intro.
- The 4–5 second intro uses CSS/SVG/emoji artwork only: dark purple-black background, bright full moon, 2–3 slowly moving fog layers, flying/flapping bats, a center pumpkin that pops in with glowing/flickering eyes and mouth, one mid-animation lightning flash, floating ghosts, orange sparks, and “Feliz Halloween” in display text (Creepster with a cursive fallback is acceptable). Put Skip in the top-right. Respect `prefers-reduced-motion` with a simple low-motion version.
- Give the existing splash screen a small Halloween detail without changing its duration.

## Halloween page

The page has three sections: countdown, games, and questions. Use Spanish as the Halloween experience's default without changing Chat IA's global language default. When the user has explicitly saved a language preference, localize the Halloween UI to that language. The four empty-chat suggestions must be translated for all five supported languages.

### Countdown

Count down to local midnight at the start of October 31. Before Halloween, target the current year; on October 31, show the special greeting and pumpkin confetti while counting toward the next October 31; after Halloween, show the greeting and count toward the next October 31. Show days, hours, minutes, and seconds, with an animated digit change that has a reduced-motion alternative.

### Games

1. **Pumpkin hunt:** 30-second round; pumpkins add points, ghosts subtract points, and bats may appear as neutral targets.
2. **Haunted memory:** match eight pairs using pumpkin, ghost, bat, spider, skeleton, cauldron, candle, and black-cat symbols; show moves and elapsed time.
3. **Catch the ghost:** a playable reaction game whose pace increases over time.

Each game has a “Jugar de nuevo” action, works on mobile and desktop, and persists its best score in `localStorage` with guarded reads and writes. A storage failure must not crash the page.

### Questions and trivia

- Provide six Halloween polls about favorite costume, trick-or-treat, horror movies, carved pumpkins versus candy, scariest monster, and favorite Halloween treat. Each has 3–4 choices, vote totals, animated percentages, and a visible “Your vote” state.
- Add five multiple-choice trivia questions with a final score and result message.
- Use stable question and option IDs so poll data remains associated with the right question after reloads.

## Poll persistence and API

Reuse the existing database table without schema changes. Map each poll question ID to `matchId`, each option ID to `teamId`, and retain the current browser-generated `voterToken` behavior. The existing semantics allow the same browser token to change its vote for a question. This is anonymous browser-level identity, not one vote per Clerk account.

Add:

- `GET /api/halloween/votes/:questionId` — return counts grouped by option.
- `POST /api/halloween/votes` — validate question ID, option ID, and voter token; insert or update the browser's vote; return updated counts.

Document both operations and their request/response schemas in OpenAPI, then regenerate the client types. Keep poll data real: show loading and actionable error/retry states rather than fabricated counts or silently swallowing failures. Do not remove historic World Cup vote records; Halloween IDs keep the two sets separate.

## Visual treatment and localization

Keep the existing dark theme. Add reusable Halloween orange (`#FF7A1A`), purple (`#7B2FBE`), and limited toxic-green (`#7CFC00`) tokens and the requested float, flicker, sway, fly, and fog animations. Use CSS, inline SVG, lucide icons, and emoji; do not add external image assets. Use a cursive fallback for Halloween display text.

Decorations on sign-in/sign-up include corner spiderwebs, a faint moon, 2–3 small bats, small pumpkins, subtle lower fog, and a restrained orange/purple glow. Chat and its empty welcome state get a corner web, a couple of small pumpkins or bats, a gently floating ghost, and a faint orange glow. All are low-opacity, behind content, and `pointer-events: none`; they must not cover forms on mobile or reduce message readability. Do not alter Clerk appearance, route behavior, copy, or sign-in/sign-up logic.

Replace the four empty-chat suggestions with Halloween prompts and suitable lucide icons in English, Spanish, Arabic, Chinese, and Japanese. Preserve the existing language picker and global default.

## Error handling, accessibility, and verification

- Keep all routes responsive and keyboard-operable; provide accessible names for interactive controls and visible focus states.
- Honor `prefers-reduced-motion` for the intro and decorative animations.
- Catch `localStorage` failures for game records and report poll/API failures with a retry path.
- Verify no active app source retains World Cup UI/API or football-data integration references. Do not count the user-provided brief or the deliberately retained `wc_votes` table as active feature references.
- Run the workspace typecheck and relevant app checks; confirm the API starts, the Halloween route renders, and poll GET/POST behavior matches the contract. Confirm existing login, chat, history, settings, and language behavior remains intact.
