import { toast } from "@/hooks/use-toast";

const showError = (msg: string) => {
  console.error("[Omni]", msg);
  toast({ variant: "destructive", title: "Omni no pudo responder", description: msg });
};

export const sendStreamingMessage = async (
  conversationId: number,
  content: string,
  onChunk: (text: string) => void,
  onDone: () => void,
  onTitleUpdate?: (title: string) => void
) => {
  const response = await fetch(`/api/openai/conversations/${conversationId}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content }),
  });

  if (!response.ok) {
    let msg = `Error del servidor (${response.status}). Revisa la ventana negra "Omni API".`;
    try { msg = (await response.json()).error || msg; } catch {}
    showError(msg);
    onDone();
    return;
  }

  if (!response.body) {
    onDone();
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    // Keep the last (possibly incomplete) line in the buffer
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      try {
        const data = JSON.parse(line.slice(6));
        if (data.done) {
          onDone();
          return;
        }
        if (data.content) {
          onChunk(data.content);
        }
        if (data.titleUpdate && onTitleUpdate) {
          onTitleUpdate(data.titleUpdate);
        }
        if (data.error) {
          showError(String(data.error));
          onDone();
          return;
        }
      } catch {
        // ignore incomplete JSON chunks
      }
    }
  }
  onDone();
};
