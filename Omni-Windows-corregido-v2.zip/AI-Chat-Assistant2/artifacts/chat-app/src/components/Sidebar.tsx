import { Link, useLocation } from "wouter";
import {
  Plus, Search, MessageSquare, Star, Settings, LogOut,
  PanelLeftClose, PanelLeftOpen, Trash2, X, Sparkles, Pencil, Check, Globe, User,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  useListOpenaiConversations,
  useSearchOpenaiConversations,
  useDeleteOpenaiConversation,
  useToggleFavoriteConversation,
  useUpdateOpenaiConversation,
  getListOpenaiConversationsQueryKey,
  getSearchOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useState, useRef } from "react";
import { useClerk, useUser } from "@clerk/react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";
import { LANGUAGES, type Language } from "@/context/LanguageContext";
import { HalloweenIntro } from "@/components/HalloweenIntro";

function PumpkinMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none">
      <path d="M11.2 5.8c-1.3-1.4-.4-3.1 1.7-3.4.1 1.6-.4 2.7-1.7 3.4Z" fill="currentColor" />
      <path d="M12 6.1c-1.8-1.2-3.7-1-5.2.2-2.8 2.3-3.1 8.5.1 10.8 1.1.8 2.5.8 3.8.3.9.5 1.8.5 2.7 0 1.3.5 2.7.5 3.8-.3 3.2-2.3 2.9-8.5.1-10.8-1.5-1.2-3.4-1.4-5.2-.2Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="m8 9.2 2.3 1.6L8 12.4m8-3.2-2.3 1.6 2.3 1.6m-4-2.2v3.6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (c: boolean) => void;
}

export function Sidebar({ collapsed, setCollapsed }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [renamingId, setRenamingId] = useState<number | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [showHalloweenIntro, setShowHalloweenIntro] = useState(false);
  const renameInputRef = useRef<HTMLInputElement>(null);
  const { user } = useUser();
  const { signOut } = useClerk();
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
  const queryClient = useQueryClient();
  const { t, language, setLanguage } = useLanguage();

  const { data: conversations, isLoading } = useListOpenaiConversations();
  const { data: searchResults } = useSearchOpenaiConversations(
    { q: searchQuery },
    { query: { enabled: searchQuery.length > 0, queryKey: getSearchOpenaiConversationsQueryKey({ q: searchQuery }) } }
  );
  const deleteConversation = useDeleteOpenaiConversation();
  const toggleFavorite = useToggleFavoriteConversation();
  const updateConversation = useUpdateOpenaiConversation();

  const displayConvos = searchQuery ? searchResults : conversations;
  const favorites = conversations?.filter((c) => c.isFavorite) ?? [];
  const recents = displayConvos?.filter((c) => !c.isFavorite) ?? [];

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.preventDefault(); e.stopPropagation();
    await deleteConversation.mutateAsync({ id });
    invalidate();
    if (location === `/chat/${id}`) setLocation("/chat");
  };

  const handleToggleFavorite = async (e: React.MouseEvent, id: number, current: boolean) => {
    e.preventDefault(); e.stopPropagation();
    await toggleFavorite.mutateAsync({ id, data: { isFavorite: !current } });
    invalidate();
  };

  const startRename = (e: React.MouseEvent, id: number, currentTitle: string) => {
    e.preventDefault(); e.stopPropagation();
    setRenamingId(id);
    setRenameValue(currentTitle || "");
    setTimeout(() => renameInputRef.current?.select(), 0);
  };

  const saveRename = async (id: number) => {
    if (renameValue.trim()) {
      await updateConversation.mutateAsync({ id, data: { title: renameValue.trim() } });
      invalidate();
    }
    setRenamingId(null);
  };

  const handleHalloweenClick = () => {
    setShowHalloweenIntro(true);
  };

  const currentLang = LANGUAGES.find((l) => l.code === language);

  const ConvoItem = ({ convo }: { convo: NonNullable<typeof conversations>[0] }) => {
    const isActive = location === `/chat/${convo.id}`;
    const isRenaming = renamingId === convo.id;

    return (
      <div onMouseEnter={() => setHoveredId(convo.id)} onMouseLeave={() => setHoveredId(null)}>
        {isRenaming ? (
          <div className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/5 border border-primary/25">
            <input
              ref={renameInputRef}
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") saveRename(convo.id); if (e.key === "Escape") setRenamingId(null); }}
              className="flex-1 bg-transparent text-[13px] text-foreground focus:outline-none min-w-0"
              autoFocus
            />
            <button onClick={() => saveRename(convo.id)} className="p-0.5 text-green-400 hover:text-green-300 flex-shrink-0"><Check className="h-3 w-3" /></button>
            <button onClick={() => setRenamingId(null)} className="p-0.5 text-muted-foreground hover:text-foreground flex-shrink-0"><X className="h-3 w-3" /></button>
          </div>
        ) : (
          <Link href={`/chat/${convo.id}`}>
            <motion.div
              layout
              initial={{ opacity: 0, x: -4 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className={`flex items-center gap-2 px-2.5 py-2 rounded-lg cursor-pointer text-[13px] transition-all duration-150 relative ${
                isActive ? "bg-white/10 text-foreground border border-white/10" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              {convo.isFavorite
                ? <Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400/50 flex-shrink-0" />
                : <MessageSquare className="h-3.5 w-3.5 opacity-40 flex-shrink-0" />
              }
              <span className="truncate flex-1">{convo.title || "New Conversation"}</span>
              <AnimatePresence>
                {hoveredId === convo.id && (
                  <motion.div
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="flex items-center gap-0.5 flex-shrink-0"
                    onClick={(e) => e.preventDefault()}
                  >
                    <button onClick={(e) => startRename(e, convo.id, convo.title || "")} className="p-1 rounded hover:bg-white/10 text-muted-foreground/50 hover:text-muted-foreground transition-colors" title="Rename"><Pencil className="h-3 w-3" /></button>
                    <button onClick={(e) => handleToggleFavorite(e, convo.id, convo.isFavorite)} className={`p-1 rounded hover:bg-white/10 transition-colors ${convo.isFavorite ? "text-yellow-400" : "text-muted-foreground/50 hover:text-yellow-400"}`}><Star className={`h-3 w-3 ${convo.isFavorite ? "fill-yellow-400/40" : ""}`} /></button>
                    <button onClick={(e) => handleDelete(e, convo.id)} className="p-1 rounded hover:bg-destructive/15 text-muted-foreground/50 hover:text-destructive transition-colors"><Trash2 className="h-3 w-3" /></button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </Link>
        )}
      </div>
    );
  };

  if (collapsed) {
    return (
      <div className="w-[56px] h-screen bg-sidebar border-r border-sidebar-border flex flex-col items-center py-3 gap-3 flex-shrink-0">
        <button onClick={() => setCollapsed(false)} className="p-2 rounded-lg text-muted-foreground/50 hover:text-muted-foreground hover:bg-white/5 transition-all">
          <PanelLeftOpen className="h-4 w-4" />
        </button>
        <button onClick={() => setLocation("/chat")} className="p-2 rounded-lg text-primary hover:bg-primary/10 border border-primary/20 transition-all" title={t.newChat}>
          <Plus className="h-4 w-4" />
        </button>
        <button
          onClick={handleHalloweenClick}
          className={`halloween-focus rounded-lg p-2 transition-all ${
            location === "/halloween" ? "border border-orange-300/25 bg-orange-300/10 text-orange-200" : "border border-orange-300/10 text-orange-200/55 hover:bg-orange-300/[.08] hover:text-orange-100"
          }`}
          title="Halloween 2026"
          aria-label="Halloween 2026"
          data-testid="button-halloween-collapsed"
        >
          <PumpkinMark />
        </button>
        <div className="flex-1" />
        <button onClick={() => setLocation("/settings")} className="p-2 rounded-lg text-muted-foreground/50 hover:text-muted-foreground hover:bg-white/5 transition-all mb-1">
          <Settings className="h-4 w-4" />
        </button>
        <AnimatePresence>
          {showHalloweenIntro && <HalloweenIntro onDone={() => { setShowHalloweenIntro(false); setLocation("/halloween"); }} />}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <>
      <div className="w-[256px] h-screen bg-sidebar border-r border-sidebar-border flex flex-col flex-shrink-0">
        {/* Brand */}
        <div className="px-4 pt-4 pb-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg overflow-hidden border border-white/10 shadow-sm flex-shrink-0">
              <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
            </div>
            <span className="font-semibold text-[15px] text-foreground tracking-tight">Omni</span>
          </div>
          <button onClick={() => setCollapsed(true)} className="p-1.5 rounded-lg text-muted-foreground/40 hover:text-muted-foreground hover:bg-white/5 transition-all">
            <PanelLeftClose className="h-4 w-4" />
          </button>
        </div>

        {/* New chat */}
        <div className="px-3 pb-3 flex-shrink-0">
          <button
            onClick={() => setLocation("/chat")}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-primary/10 hover:bg-primary/16 text-primary border border-primary/20 hover:border-primary/35 text-sm font-medium transition-all duration-150"
          >
            <Plus className="h-4 w-4" />
            {t.newChat}
          </button>
        </div>

        {/* Search */}
        <div className="px-3 pb-2 relative flex-shrink-0">
          <Search className="h-3.5 w-3.5 absolute left-6 top-1/2 -translate-y-1/2 text-muted-foreground/35 pointer-events-none" />
          <Input
            placeholder={t.search}
            className="pl-8 pr-7 h-8 bg-white/4 border-white/8 focus-visible:ring-primary/30 text-[13px] placeholder:text-muted-foreground/35 rounded-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} className="absolute right-6 top-1/2 -translate-y-1/2 text-muted-foreground/40 hover:text-muted-foreground">
              <X className="h-3 w-3" />
            </button>
          )}
        </div>

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto px-2 py-1 custom-scrollbar space-y-4">
          {!searchQuery && favorites.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold text-muted-foreground/35 mb-1.5 px-2.5 uppercase tracking-widest">{t.favorites}</p>
              <div className="space-y-0.5">{favorites.map((c) => <ConvoItem key={c.id} convo={c} />)}</div>
            </div>
          )}
          <div>
            <p className="text-[10px] font-semibold text-muted-foreground/35 mb-1.5 px-2.5 uppercase tracking-widest">
              {searchQuery ? "Results" : t.recent}
            </p>
            <div className="space-y-0.5">
              {isLoading ? (
                <div className="space-y-1.5 px-1 py-2">
                  {[1,2,3,4].map((i) => <div key={i} className="h-7 rounded-lg bg-white/4 animate-pulse" />)}
                </div>
              ) : recents.length === 0 ? (
                <p className="px-2.5 py-4 text-[12px] text-muted-foreground/35 text-center">{searchQuery ? "No results" : t.noChats}</p>
              ) : (
                <AnimatePresence>{recents.map((c) => <ConvoItem key={c.id} convo={c} />)}</AnimatePresence>
              )}
            </div>
          </div>
        </div>

        {/* ── Footer navigation ── */}
        <div className="border-t border-sidebar-border flex-shrink-0 pb-1">
          {/* Language picker flyout */}
          <AnimatePresence>
            {showLangPicker && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                className="px-2 pt-2 pb-1"
              >
                <p className="text-[10px] font-semibold text-muted-foreground/35 px-2 mb-1.5 uppercase tracking-widest">{t.language}</p>
                <div className="space-y-0.5">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => { setLanguage(lang.code as Language); setShowLangPicker(false); }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-[13px] transition-all ${
                        language === lang.code
                          ? "bg-primary/12 text-primary border border-primary/20"
                          : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                      }`}
                    >
                      <span className="text-base leading-none">{lang.flag}</span>
                      <span>{lang.label}</span>
                      {language === lang.code && <Check className="h-3 w-3 ml-auto" />}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="px-2 pt-2 space-y-0.5">
            {/* Seasonal side-space */}
            <button
              onClick={handleHalloweenClick}
              data-testid="button-halloween-sidebar"
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[13px] transition-all ${
                location === "/halloween"
                  ? "bg-orange-300/10 text-orange-100 border border-orange-200/15"
                  : "text-orange-200/60 hover:bg-orange-200/[.06] hover:text-orange-100"
              }`}
            >
              <PumpkinMark />
              <span className="flex-1 text-left">Halloween 2026</span>
              <span className="h-1.5 w-1.5 rounded-full bg-orange-300/70" />
            </button>

            {/* Language */}
            <button
              onClick={() => setShowLangPicker(!showLangPicker)}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[13px] transition-all ${
                showLangPicker ? "bg-white/8 text-foreground" : "text-muted-foreground/60 hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <Globe className="h-4 w-4 flex-shrink-0" />
              <span className="flex-1 text-left">{t.language}</span>
              <span className="text-base leading-none">{currentLang?.flag}</span>
            </button>

            {/* Settings */}
            <Link href="/settings">
              <div className={`flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[13px] transition-all cursor-pointer ${
                location === "/settings" ? "bg-white/8 text-foreground" : "text-muted-foreground/60 hover:bg-white/5 hover:text-foreground"
              }`}>
                <Settings className="h-4 w-4 flex-shrink-0" />
                {t.settings}
              </div>
            </Link>

            {/* Profile */}
            <div className="flex items-center gap-1 pt-1 border-t border-white/5 mt-1">
              <Link href="/settings">
                <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors flex-1 min-w-0">
                  <Avatar className="h-7 w-7 rounded-lg border border-white/10 flex-shrink-0">
                    <AvatarImage src={user?.imageUrl} />
                    <AvatarFallback className="bg-gradient-to-br from-primary/40 to-purple-500/40 text-white text-xs rounded-lg font-semibold">
                      {user?.firstName?.charAt(0) ?? "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="text-[13px] font-medium text-foreground truncate leading-snug">{user?.fullName ?? "User"}</span>
                    <span className="text-[11px] text-muted-foreground/40 leading-snug">Free Plan</span>
                  </div>
                </div>
              </Link>
              <button
                onClick={() => signOut({ redirectUrl: basePath || "/" })}
                className="p-2 rounded-xl text-muted-foreground/35 hover:text-destructive/80 hover:bg-destructive/8 transition-all flex-shrink-0"
                title={t.signOut}
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* World Cup intro overlay */}
      <AnimatePresence>
        {showHalloweenIntro && (
          <HalloweenIntro onDone={() => { setShowHalloweenIntro(false); setLocation("/halloween"); }} />
        )}
      </AnimatePresence>
    </>
  );
}
