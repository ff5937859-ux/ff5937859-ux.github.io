import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

interface SplashScreenProps {
  onDone: () => void;
}

export function SplashScreen({ onDone }: SplashScreenProps) {
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("hold"), 600);
    const t2 = setTimeout(() => setPhase("out"), 2200);
    const t3 = setTimeout(() => onDone(), 2800);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <AnimatePresence>
      {phase !== "out" ? (
        <motion.div
          key="splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background"
        >
          {/* Glow background */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/12 rounded-full blur-[120px]" />
            <div className="absolute top-1/3 left-1/3 w-[300px] h-[300px] bg-purple-600/8 rounded-full blur-[80px]" />
            <svg className="absolute bottom-0 left-1/2 h-44 w-full max-w-5xl -translate-x-1/2 text-orange-200/[.08]" viewBox="0 0 1000 180" fill="none" aria-hidden="true">
              <path d="M0 160h1000M86 160v-70h52v70m-42-70V63h32v27m91 70V98h76v62m-62-62V77h47v21m577 62V87h70v73m-53-73V62h36v25m86 73V108h46v52" stroke="currentColor" strokeWidth="2" />
              <circle cx="785" cy="45" r="18" stroke="currentColor" />
              <path d="m785 18 4 10 10 4-10 4-4 10-4-10-10-4 10-4 4-10Z" fill="currentColor" />
            </svg>
          </div>

          {/* Logo */}
          <motion.div
            initial={{ scale: 0.6, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="relative mb-6"
          >
            <div className="absolute inset-0 scale-150 bg-primary/20 rounded-full blur-2xl" />
            <div className="relative w-28 h-28 rounded-3xl overflow-hidden border border-white/15 shadow-[0_0_60px_rgba(79,142,247,.6)]">
              <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
            </div>
          </motion.div>

          {/* Name */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.4 }}
            className="flex flex-col items-center gap-1.5"
          >
            <h1 className="text-4xl font-extrabold tracking-tight gradient-text">Omni</h1>
            <p className="text-sm text-muted-foreground/50 tracking-widest uppercase">Your AI Assistant</p>
          </motion.div>

          {/* Loading bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="absolute bottom-16 left-1/2 -translate-x-1/2 w-32 h-[2px] bg-white/8 rounded-full overflow-hidden"
          >
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: "100%" }}
              transition={{ duration: 1.4, ease: "easeInOut", delay: 0.5 }}
              className="absolute inset-y-0 left-0 w-full bg-gradient-to-r from-transparent via-primary to-transparent"
            />
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
