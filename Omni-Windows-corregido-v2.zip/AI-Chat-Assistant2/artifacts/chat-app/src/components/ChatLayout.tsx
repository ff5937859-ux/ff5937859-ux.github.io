import { Sidebar } from "@/components/Sidebar";
import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu } from "lucide-react";

interface ChatLayoutProps {
  children: React.ReactNode;
  headerSlot?: React.ReactNode;
}

export function ChatLayout({ children, headerSlot }: ChatLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setCollapsed(false);
    };
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden selection:bg-primary/25">
      {/* Desktop sidebar */}
      {!isMobile && (
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      )}

      {/* Mobile overlay */}
      {isMobile && (
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div
                key="overlay"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileOpen(false)}
                className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
              />
              <motion.div
                key="mobile-sidebar"
                initial={{ x: -270 }}
                animate={{ x: 0 }}
                exit={{ x: -270 }}
                transition={{ type: "spring", damping: 28, stiffness: 300 }}
                className="fixed left-0 top-0 h-full z-50"
              >
                <Sidebar
                  collapsed={false}
                  setCollapsed={() => setMobileOpen(false)}
                />
              </motion.div>
            </>
          )}
        </AnimatePresence>
      )}

      {/* Main content */}
      <main className="flex-1 flex flex-col relative h-full min-w-0 overflow-hidden">
        {/* Mobile header bar with hamburger */}
        {isMobile && (
          <div className="flex items-center gap-2 px-3 py-2 border-b border-white/5 bg-background/95 backdrop-blur-sm flex-shrink-0 z-20">
            <button
              onClick={() => setMobileOpen(true)}
              className="p-2 rounded-xl bg-white/6 hover:bg-white/10 border border-white/8 text-muted-foreground/60 hover:text-foreground transition-all"
              aria-label="Open sidebar"
            >
              <Menu className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <div className="w-6 h-6 rounded-lg overflow-hidden border border-white/10 flex-shrink-0">
                <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
              </div>
              <span className="text-sm font-semibold text-foreground truncate">Omni</span>
            </div>
          </div>
        )}
        {headerSlot}
        {children}
      </main>
    </div>
  );
}
