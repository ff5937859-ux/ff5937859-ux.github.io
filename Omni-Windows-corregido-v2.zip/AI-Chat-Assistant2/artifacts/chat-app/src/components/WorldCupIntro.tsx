import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

interface WorldCupIntroProps {
  onDone: () => void;
}

const SPARKS = Array.from({ length: 18 }, (_, i) => ({
  id: i,
  angle: (i / 18) * 360,
  dist: 80 + Math.random() * 80,
  delay: 0.3 + Math.random() * 0.5,
  size: 4 + Math.random() * 6,
}));

export function WorldCupIntro({ onDone }: WorldCupIntroProps) {
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("hold"), 800);
    const t2 = setTimeout(() => setPhase("out"), 8500);
    const t3 = setTimeout(() => onDone(), 9200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  const isVisible = phase !== "out";

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          key="wc-intro"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="fixed inset-0 z-[9998] flex flex-col items-center justify-center overflow-hidden"
          style={{ background: "linear-gradient(135deg, #0a0a0f 0%, #0d1f3c 50%, #0a0a0f 100%)" }}
        >
          {/* Animated background */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-primary/5"
            />
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border border-yellow-400/5"
            />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[80px]" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-yellow-400/8 rounded-full blur-[60px]" />
          </div>

          {/* Spark particles */}
          <div className="absolute top-1/2 left-1/2 pointer-events-none">
            {SPARKS.map((s) => {
              const rad = (s.angle * Math.PI) / 180;
              const tx = Math.cos(rad) * s.dist;
              const ty = Math.sin(rad) * s.dist;
              return (
                <motion.div
                  key={s.id}
                  initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                  animate={{ x: tx, y: ty, opacity: [0, 1, 1, 0], scale: [0, 1.2, 1, 0] }}
                  transition={{ delay: s.delay, duration: 1.5, ease: "easeOut" }}
                  className="absolute rounded-full bg-yellow-400"
                  style={{ width: s.size, height: s.size, marginLeft: -s.size / 2, marginTop: -s.size / 2 }}
                />
              );
            })}
          </div>

          {/* Decorative image (top right) */}
          <motion.img
            src="/wc-decor.png"
            alt=""
            initial={{ opacity: 0, scale: 0.7, rotate: -15 }}
            animate={{ opacity: 0.15, scale: 1, rotate: 0 }}
            transition={{ delay: 0.5, duration: 1.2, ease: "easeOut" }}
            className="absolute top-8 right-8 w-48 h-48 object-contain pointer-events-none"
          />
          <motion.img
            src="/wc-decor.png"
            alt=""
            initial={{ opacity: 0, scale: 0.7, rotate: 15 }}
            animate={{ opacity: 0.12, scale: 1, rotate: 0 }}
            transition={{ delay: 0.7, duration: 1.2, ease: "easeOut" }}
            className="absolute bottom-8 left-8 w-40 h-40 object-contain pointer-events-none scale-x-[-1]"
          />

          {/* Main content */}
          <div className="relative z-10 flex flex-col items-center gap-6 text-center px-8">
            {/* WC Icon */}
            <motion.div
              initial={{ scale: 0.3, opacity: 0, rotate: -20 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="relative"
            >
              <motion.div
                animate={{ scale: [1, 1.06, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="w-36 h-36 relative">
                  <div className="absolute inset-0 bg-yellow-400/20 rounded-full blur-2xl scale-150" />
                  <img
                    src="/wc-icon.png"
                    alt="FIFA World Cup 2026"
                    className="relative w-full h-full object-contain drop-shadow-[0_0_30px_rgba(250,204,21,0.5)]"
                  />
                </div>
              </motion.div>
            </motion.div>

            {/* Title */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="space-y-2"
            >
              <div className="text-xs font-semibold text-primary/60 tracking-[0.25em] uppercase">FIFA</div>
              <h1 className="text-5xl md:text-6xl font-black tracking-tight leading-none">
                <span className="text-white">World Cup</span>
                <br />
                <span className="text-yellow-400">2026</span>
              </h1>
              <p className="text-muted-foreground/60 text-base mt-3">USA · Canada · Mexico</p>
            </motion.div>

            {/* Live badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.2, duration: 0.5 }}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/15 border border-red-500/30"
            >
              <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              <span className="text-sm font-semibold text-red-400">LIVE SCORES &amp; STATS</span>
            </motion.div>

            {/* Skip button */}
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              onClick={() => { setPhase("out"); setTimeout(onDone, 500); }}
              className="text-xs text-muted-foreground/30 hover:text-muted-foreground/60 transition-colors mt-4"
            >
              Skip →
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
