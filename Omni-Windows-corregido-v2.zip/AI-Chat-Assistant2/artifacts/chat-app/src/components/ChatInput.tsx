import { useState, useRef, useEffect } from "react";
import { Send, Square, Globe } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";

interface ChatInputProps {
  onSend: (message: string) => void;
  onStop?: () => void;
  disabled?: boolean;
  isStreaming?: boolean;
  webSearchEnabled?: boolean;
  onToggleWebSearch?: () => void;
}

export function ChatInput({ onSend, onStop, disabled, isStreaming, webSearchEnabled, onToggleWebSearch }: ChatInputProps) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { t } = useLanguage();

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [value]);

  useEffect(() => {
    if (!disabled && !isStreaming && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [disabled, isStreaming]);

  const handleSend = () => {
    if (value.trim() && !disabled && !isStreaming) {
      onSend(value.trim());
      setValue("");
      if (textareaRef.current) textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canSend = value.trim().length > 0;

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className={`relative flex flex-col rounded-2xl bg-card border transition-all duration-200 shadow-lg input-ring ${
        canSend ? "border-primary/30" : "border-white/8"
      }`}>
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={t.placeholder}
          className="flex-1 min-h-[54px] max-h-[200px] resize-none border-0 bg-transparent py-4 pl-5 pr-14 focus:outline-none text-sm text-foreground placeholder:text-muted-foreground/40 leading-relaxed custom-scrollbar"
          disabled={isStreaming}
          rows={1}
        />

        {/* Bottom toolbar */}
        <div className="flex items-center justify-between px-3 pb-2.5">
          {/* Web search toggle */}
          <button
            type="button"
            onClick={onToggleWebSearch}
            title="Toggle web search"
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 border ${
              webSearchEnabled
                ? "bg-primary/12 border-primary/30 text-primary"
                : "border-white/8 text-muted-foreground/40 hover:text-muted-foreground hover:border-white/15 hover:bg-white/4"
            }`}
          >
            <Globe className="h-3.5 w-3.5" />
            <span>Web</span>
            {webSearchEnabled && (
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            )}
          </button>

          {/* Send / Stop button */}
          <AnimatePresence mode="wait">
            {isStreaming ? (
              <motion.button
                key="stop"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onClick={onStop}
                className="w-9 h-9 rounded-xl bg-primary/15 hover:bg-primary/25 border border-primary/30 text-primary flex items-center justify-center transition-all duration-150"
                title="Stop generation"
              >
                <Square className="h-4 w-4 fill-current" />
              </motion.button>
            ) : (
              <motion.button
                key="send"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                onClick={handleSend}
                disabled={!canSend || disabled}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-150 ${
                  canSend && !disabled
                    ? "bg-primary hover:bg-primary/90 text-white shadow-[0_0_12px_rgba(79,142,247,.4)] glow-blue-sm"
                    : "bg-white/5 text-muted-foreground/30 cursor-not-allowed"
                }`}
                title="Send message"
              >
                <Send className="h-4 w-4" />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>

      <p className="text-center mt-2.5 text-[11px] text-muted-foreground/30 leading-relaxed">
        {t.disclaimer}
      </p>
    </div>
  );
}
