import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Moon, Sparkles } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

const INTRO_COPY = {
  es: { eyebrow: "OMNI PRESENTA", title: "La noche te espera.", line: "Un pequeño desvío para jugar y elegir.", skip: "Saltar" },
  en: { eyebrow: "OMNI PRESENTS", title: "The night is waiting.", line: "A small detour to play and choose.", skip: "Skip" },
  ar: { eyebrow: "OMNI تقدّم", title: "الليل بانتظارك.", line: "استراحة صغيرة للعب والاختيار.", skip: "تخطّي" },
  zh: { eyebrow: "OMNI 呈现", title: "夜晚正等着你。", line: "稍作停留，玩一玩，选一选。", skip: "跳过" },
  ja: { eyebrow: "OMNI より", title: "夜が待っています。", line: "遊んで選ぶ、小さな寄り道。", skip: "スキップ" },
} as const;

export function HalloweenIntro({ onDone }: { onDone: () => void }) {
  const { language } = useLanguage();
  const reducedMotion = useReducedMotion();
  const [leaving, setLeaving] = useState(false);
  const doneRef = useRef(false);
  const copy = (() => {
    try {
      const saved = localStorage.getItem("chatai-language");
      return saved && saved in INTRO_COPY ? INTRO_COPY[saved as keyof typeof INTRO_COPY] : INTRO_COPY.es;
    } catch {
      return language === "es" ? INTRO_COPY.es : INTRO_COPY[language as keyof typeof INTRO_COPY] ?? INTRO_COPY.es;
    }
  })();

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    setLeaving(true);
    window.setTimeout(onDone, reducedMotion ? 0 : 420);
  };

  useEffect(() => {
    const timer = window.setTimeout(finish, 4500);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: leaving ? 0 : 1 }}
      transition={{ duration: reducedMotion ? 0 : 0.45 }}
      className="fixed inset-0 z-[100] flex min-h-[100dvh] items-center justify-center overflow-hidden bg-[#100d14] px-6 text-center"
      role="dialog"
      aria-modal="true"
      aria-label={copy.title}
    >
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute left-1/2 top-1/2 h-[min(70vw,560px)] w-[min(70vw,560px)] -translate-x-1/2 -translate-y-1/2 rounded-full border border-orange-200/[.07]" />
        <div className="absolute left-1/2 top-1/2 h-[min(54vw,420px)] w-[min(54vw,420px)] -translate-x-1/2 -translate-y-1/2 rounded-full border border-violet-200/[.08]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_44%,rgba(157,86,46,.16),transparent_45%)]" />
      </div>
      <motion.div
        initial={reducedMotion ? {} : { opacity: 0, y: 18, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: reducedMotion ? 0 : 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative max-w-xl"
      >
        <div className="mx-auto mb-7 flex h-20 w-20 items-center justify-center rounded-[1.7rem] border border-orange-200/15 bg-orange-200/[.06] text-orange-100 shadow-[0_20px_70px_rgba(130,63,33,.18)]">
          <Moon className="h-9 w-9" strokeWidth={1.25} />
        </div>
        <p className="mb-4 flex items-center justify-center gap-2 text-[10px] font-semibold tracking-[.28em] text-orange-100/60">
          <Sparkles className="h-3 w-3" /> {copy.eyebrow}
        </p>
        <h1 className="font-serif text-4xl font-medium tracking-[-.04em] text-orange-50 sm:text-6xl">{copy.title}</h1>
        <p className="mt-4 text-sm text-violet-100/55">{copy.line}</p>
        <button
          type="button"
          onClick={finish}
          data-testid="button-skip-halloween-intro"
          className="halloween-focus mt-10 rounded-full border border-white/10 px-5 py-2 text-xs text-muted-foreground transition-colors hover:border-orange-200/25 hover:text-orange-100"
        >
          {copy.skip}
        </button>
      </motion.div>
    </motion.div>
  );
}
