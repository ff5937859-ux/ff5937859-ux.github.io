import { type OpenaiMessage } from "@workspace/api-client-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Copy, Check, RefreshCw, ThumbsUp, ThumbsDown, Star, Share2, Globe } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";

interface MessageBubbleProps {
  message: Pick<OpenaiMessage, "content" | "role" | "createdAt">;
  isStreaming?: boolean;
  onRegenerate?: () => void;
}

function ActionButton({
  icon: Icon,
  label,
  onClick,
  active = false,
  activeClass = "text-primary",
}: {
  icon: React.ElementType;
  label: string;
  onClick?: () => void;
  active?: boolean;
  activeClass?: string;
}) {
  return (
    <button
      onClick={onClick}
      title={label}
      className={`p-1.5 rounded-lg transition-all duration-150 hover:bg-white/7 ${
        active ? activeClass : "text-muted-foreground/40 hover:text-muted-foreground"
      }`}
    >
      <Icon className={`h-3.5 w-3.5 ${active ? "fill-current" : ""}`} />
    </button>
  );
}

export function WebSearchIndicator({ text }: { text: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="flex items-center gap-3 py-2"
    >
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/8 border border-primary/15">
        <div className="relative w-4 h-4 flex-shrink-0">
          <Globe className="h-4 w-4 text-primary/70 absolute inset-0" />
          <motion.div
            className="absolute inset-0 rounded-full border border-primary/40"
            animate={{ scale: [1, 1.6, 1], opacity: [0.6, 0, 0.6] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }}
          />
        </div>
        <span className="text-xs text-primary/70 font-medium">{text}</span>
        <div className="flex gap-0.5 ml-1">
          <span className="typing-dot w-1.5 h-1.5 rounded-full bg-primary/50 inline-block" />
          <span className="typing-dot w-1.5 h-1.5 rounded-full bg-primary/50 inline-block" />
          <span className="typing-dot w-1.5 h-1.5 rounded-full bg-primary/50 inline-block" />
        </div>
      </div>
    </motion.div>
  );
}

export function MessageBubble({ message, isStreaming, onRegenerate }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const { t } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState<null | "up" | "down">(null);
  const [starred, setStarred] = useState(false);
  const [shared, setShared] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ text: message.content }).catch(() => {});
    } else {
      navigator.clipboard.writeText(message.content);
      setShared(true);
      setTimeout(() => setShared(false), 2000);
    }
  };

  if (isUser) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.18, ease: "easeOut" }}
        className="flex justify-end group"
      >
        <div className="max-w-[75%]">
          <div className="px-4 py-3 rounded-2xl rounded-tr-sm bg-primary text-white text-sm leading-relaxed whitespace-pre-wrap break-words shadow-sm">
            {message.content}
          </div>
          <div className="flex justify-end mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="text-[11px] text-muted-foreground/30 px-1">
              {message.createdAt && new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.18, ease: "easeOut" }}
      className="flex justify-start group"
    >
      {/* AI icon */}
      <div className="flex-shrink-0 w-7 h-7 rounded-lg overflow-hidden mr-3 mt-0.5 border border-white/10 shadow-sm">
        <img src="/ai-icon.png" alt="Omni" className="w-full h-full object-cover" />
      </div>

      <div className="flex-1 min-w-0 max-w-[85%]">
        {/* Clean prose text — ChatGPT style */}
        <div className={`text-sm leading-[1.75] text-foreground/90 break-words
          prose prose-sm dark:prose-invert max-w-none
          prose-p:my-2.5 prose-p:leading-[1.75]
          prose-headings:font-semibold prose-headings:text-foreground prose-headings:mt-5 prose-headings:mb-2
          prose-h1:text-xl prose-h2:text-lg prose-h3:text-base
          prose-a:text-primary prose-a:no-underline hover:prose-a:underline
          prose-strong:text-foreground prose-strong:font-semibold
          prose-em:text-foreground/80
          prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-[0.8em] prose-code:font-mono prose-code:before:content-none prose-code:after:content-none
          prose-pre:bg-transparent prose-pre:p-0 prose-pre:m-0
          prose-blockquote:border-l-2 prose-blockquote:border-primary/40 prose-blockquote:pl-4 prose-blockquote:text-muted-foreground prose-blockquote:not-italic
          prose-ul:my-2.5 prose-ul:space-y-1 prose-li:my-0
          prose-ol:my-2.5 prose-ol:space-y-1
          prose-hr:border-border
          ${isStreaming ? "streaming-cursor" : ""}
        `}>
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              code({ node, inline, className, children, ...props }: any) {
                const match = /language-(\w+)/.exec(className || "");
                const code = String(children).replace(/\n$/, "");
                if (!inline && match) {
                  return (
                    <div className="my-4 rounded-xl overflow-hidden border border-white/8 shadow-lg text-[0.8rem]">
                      <div className="flex items-center justify-between px-4 py-2.5 bg-[#1a1a2e] border-b border-white/6">
                        <div className="flex items-center gap-2.5">
                          <div className="flex gap-1.5">
                            <div className="w-2.5 h-2.5 rounded-full bg-[#ff5f57]" />
                            <div className="w-2.5 h-2.5 rounded-full bg-[#febc2e]" />
                            <div className="w-2.5 h-2.5 rounded-full bg-[#28c840]" />
                          </div>
                          <span className="text-[11px] font-mono text-muted-foreground/50 capitalize">{match[1]}</span>
                        </div>
                        <button
                          onClick={() => navigator.clipboard.writeText(code)}
                          className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs text-muted-foreground/50 hover:text-muted-foreground hover:bg-white/6 transition-all duration-150"
                        >
                          <Copy className="h-3 w-3" />
                          Copy
                        </button>
                      </div>
                      <SyntaxHighlighter
                        style={vscDarkPlus as any}
                        language={match[1]}
                        PreTag="div"
                        customStyle={{ margin: 0, borderRadius: 0, background: "#0d1117", fontSize: "0.8125rem", lineHeight: "1.65", padding: "1.125rem 1.25rem" }}
                        {...props}
                      >
                        {code}
                      </SyntaxHighlighter>
                    </div>
                  );
                }
                return (
                  <code className="bg-primary/10 text-primary px-1.5 py-0.5 rounded text-[0.8em] font-mono" {...props}>
                    {children}
                  </code>
                );
              },
              table({ children }) {
                return (
                  <div className="overflow-x-auto my-4 rounded-lg border border-border">
                    <table className="w-full">{children}</table>
                  </div>
                );
              },
              th({ children }) {
                return <th className="px-4 py-2.5 text-left font-semibold text-xs uppercase tracking-wide bg-white/5 border-b border-border text-muted-foreground">{children}</th>;
              },
              td({ children }) {
                return <td className="px-4 py-2.5 border-b border-border/40 text-foreground/80 text-sm">{children}</td>;
              },
            }}
          >
            {message.content}
          </ReactMarkdown>
        </div>

        {/* Action row — appears on hover, hidden during streaming */}
        {!isStreaming && (
          <div className="flex items-center gap-0.5 mt-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            {/* Copy */}
            <button
              onClick={handleCopy}
              title={t.copy}
              className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs transition-all duration-150 hover:bg-white/7 ${copied ? "text-green-400" : "text-muted-foreground/40 hover:text-muted-foreground"}`}
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">{copied ? t.copied : t.copy}</span>
            </button>

            {/* Like */}
            <ActionButton
              icon={ThumbsUp}
              label="Like"
              active={liked === "up"}
              activeClass="text-green-400"
              onClick={() => setLiked(liked === "up" ? null : "up")}
            />

            {/* Dislike */}
            <ActionButton
              icon={ThumbsDown}
              label="Dislike"
              active={liked === "down"}
              activeClass="text-destructive"
              onClick={() => setLiked(liked === "down" ? null : "down")}
            />

            {/* Star */}
            <ActionButton
              icon={Star}
              label="Save"
              active={starred}
              activeClass="text-yellow-400"
              onClick={() => setStarred(!starred)}
            />

            {/* Share */}
            <ActionButton
              icon={Share2}
              label={t.share}
              active={shared}
              activeClass="text-primary"
              onClick={handleShare}
            />

            {/* Regenerate */}
            {onRegenerate && (
              <button
                onClick={onRegenerate}
                title={t.regenerate}
                className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs text-muted-foreground/40 hover:text-muted-foreground hover:bg-white/7 transition-all"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t.regenerate}</span>
              </button>
            )}

            {/* Timestamp */}
            <span className="text-[11px] text-muted-foreground/20 px-1.5 ml-auto">
              {message.createdAt && new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export function TypingIndicator({ text }: { text?: string }) {
  const { t } = useLanguage();
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="flex items-center gap-3 py-1"
    >
      <div className="flex-shrink-0 w-7 h-7 rounded-lg overflow-hidden border border-white/10 shadow-sm">
        <img src="/ai-icon.png" alt="Omni" className="w-full h-full object-cover" />
      </div>
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5">
          <span className="typing-dot w-2 h-2 rounded-full bg-primary/60 inline-block" />
          <span className="typing-dot w-2 h-2 rounded-full bg-primary/60 inline-block" />
          <span className="typing-dot w-2 h-2 rounded-full bg-primary/60 inline-block" />
        </div>
        <span className="text-xs text-muted-foreground/40">{text ?? t.thinking}</span>
      </div>
    </motion.div>
  );
}
