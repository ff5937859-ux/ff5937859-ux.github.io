import { useState, useRef } from "react";
import { Pencil, Check, X } from "lucide-react";
import { useUpdateOpenaiConversation, getListOpenaiConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

interface ChatHeaderProps {
  title?: string;
  conversationId?: number | null;
  onTitleChange?: (t: string) => void;
}

export function ChatHeader({ title, conversationId, onTitleChange }: ChatHeaderProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const updateConversation = useUpdateOpenaiConversation();
  const queryClient = useQueryClient();

  const startEdit = () => {
    setDraft(title || "");
    setEditing(true);
    setTimeout(() => inputRef.current?.select(), 0);
  };

  const cancelEdit = () => setEditing(false);

  const saveEdit = async () => {
    const trimmed = draft.trim();
    if (!conversationId || !trimmed || trimmed === title) {
      setEditing(false);
      return;
    }
    await updateConversation.mutateAsync({ id: conversationId, data: { title: trimmed } });
    queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    onTitleChange?.(trimmed);
    setEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") saveEdit();
    if (e.key === "Escape") cancelEdit();
  };

  return (
    <div className="group flex items-center gap-3 px-5 py-3 border-b border-border/30 bg-background/70 backdrop-blur-md flex-shrink-0 min-h-[52px]">
      {/* Title */}
      <div className="flex items-center gap-2 flex-1 min-w-0">
        {editing ? (
          <div className="flex items-center gap-2 flex-1">
            <input
              ref={inputRef}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 bg-white/6 border border-primary/30 rounded-lg px-3 py-1.5 text-[13px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 min-w-0"
              autoFocus
            />
            <button
              onClick={saveEdit}
              className="p-1.5 rounded-lg hover:bg-green-500/12 text-green-400 transition-colors flex-shrink-0"
            >
              <Check className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={cancelEdit}
              className="p-1.5 rounded-lg hover:bg-white/6 text-muted-foreground transition-colors flex-shrink-0"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 min-w-0">
            <h1 className="text-[13px] font-medium text-foreground/80 truncate">
              {title || "New Conversation"}
            </h1>
            {conversationId && (
              <button
                onClick={startEdit}
                className="p-1 rounded-md text-muted-foreground/25 hover:text-muted-foreground/60 hover:bg-white/5 transition-all flex-shrink-0 opacity-0 group-hover:opacity-100"
                title="Rename conversation"
              >
                <Pencil className="h-3 w-3" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Status indicator */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <div className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_5px_rgba(74,222,128,.7)]" />
        <span className="text-[11px] text-muted-foreground/35 hidden sm:block tracking-wide">
          GPT-4o
        </span>
      </div>
    </div>
  );
}
