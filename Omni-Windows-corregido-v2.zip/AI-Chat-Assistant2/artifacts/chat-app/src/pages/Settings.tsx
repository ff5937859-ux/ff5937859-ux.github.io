import { ChatLayout } from "@/components/ChatLayout";
import { useClerk, useUser } from "@clerk/react";
import {
  useListOpenaiConversations,
  useDeleteOpenaiConversation,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { Trash2, LogOut, Moon, User, Shield, Database, Globe, Check } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { motion } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";
import { LANGUAGES, type Language } from "@/context/LanguageContext";

const Section = ({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) => (
  <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>
    <div className="flex items-center gap-2 mb-3">
      <div className="w-6 h-6 rounded-md bg-primary/10 flex items-center justify-center">
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <h2 className="text-sm font-semibold text-foreground/80 uppercase tracking-wider">{title}</h2>
    </div>
    <div className="rounded-2xl bg-card border border-white/7 overflow-hidden shadow-sm">{children}</div>
  </motion.section>
);

const Row = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <div className={`flex items-center justify-between px-5 py-4 border-b border-white/5 last:border-0 ${className}`}>{children}</div>
);

export default function Settings() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
  const { data: conversations } = useListOpenaiConversations();
  const deleteConversation = useDeleteOpenaiConversation();
  const queryClient = useQueryClient();
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const handleClearHistory = async () => {
    if (!conversations?.length) return;
    setIsClearing(true);
    try {
      for (const conv of conversations) {
        await deleteConversation.mutateAsync({ id: conv.id });
      }
      queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    } finally {
      setIsClearing(false);
      setShowClearDialog(false);
    }
  };

  return (
    <ChatLayout>
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-2xl mx-auto px-4 md:px-8 py-10">
          <div className="mb-10">
            <h1 className="text-2xl font-bold mb-1">{t.settings}</h1>
            <p className="text-sm text-muted-foreground">Manage your account and preferences.</p>
          </div>

          <div className="space-y-8">
            {/* Profile */}
            <Section title={t.profile} icon={User}>
              <Row>
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12 rounded-xl border border-white/10">
                    <AvatarImage src={user?.imageUrl} />
                    <AvatarFallback className="bg-gradient-to-br from-primary/40 to-purple-500/40 text-white font-semibold rounded-xl text-base">
                      {user?.firstName?.charAt(0) ?? "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-foreground">{user?.fullName ?? "User"}</p>
                    <p className="text-sm text-muted-foreground">{user?.primaryEmailAddress?.emailAddress}</p>
                  </div>
                </div>
                <span className="text-xs text-primary bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-full font-medium">Free Plan</span>
              </Row>
              <Row>
                <div>
                  <p className="text-sm font-medium text-foreground">{t.signOut}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Sign out of your Omni account</p>
                </div>
                <button
                  onClick={() => signOut({ redirectUrl: basePath || "/" })}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/8 hover:border-destructive/30 hover:bg-destructive/8 text-sm text-muted-foreground hover:text-destructive transition-all duration-150"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  {t.signOut}
                </button>
              </Row>
            </Section>

            {/* Language */}
            <Section title={t.language} icon={Globe}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">
                {LANGUAGES.map((lang, i) => (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code as Language)}
                    className={`flex items-center gap-3 px-5 py-4 border-b border-white/5 last:border-0 sm:even:border-l transition-all duration-150 text-left ${
                      language === lang.code
                        ? "bg-primary/8 text-foreground"
                        : "hover:bg-white/4 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <span className="text-2xl leading-none">{lang.flag}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{lang.label}</p>
                      <p className="text-xs text-muted-foreground/50">{lang.code.toUpperCase()}</p>
                    </div>
                    {language === lang.code && <Check className="h-4 w-4 text-primary flex-shrink-0" />}
                  </button>
                ))}
              </div>
            </Section>

            {/* Appearance */}
            <Section title="Appearance" icon={Moon}>
              <Row>
                <div>
                  <p className="text-sm font-medium text-foreground">Theme</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Omni is designed exclusively in dark mode for optimal focus.</p>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/8 text-sm text-muted-foreground">
                  <Moon className="h-3.5 w-3.5 text-primary" />
                  Dark
                </div>
              </Row>
            </Section>

            {/* Data & Privacy */}
            <Section title="Data & Privacy" icon={Shield}>
              <Row>
                <div>
                  <p className="text-sm font-medium text-foreground">Chat History</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {conversations?.length ? `${conversations.length} conversation${conversations.length !== 1 ? "s" : ""} stored` : "No conversations yet"}
                  </p>
                </div>
                <button
                  onClick={() => setShowClearDialog(true)}
                  disabled={!conversations?.length || isClearing}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/8 hover:border-destructive/40 hover:bg-destructive/8 text-sm text-muted-foreground hover:text-destructive transition-all duration-150 disabled:opacity-40 disabled:pointer-events-none"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Clear All
                </button>
              </Row>
              <Row>
                <div>
                  <p className="text-sm font-medium text-foreground">Data Storage</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Conversations are stored securely in your account database.</p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground/50">
                  <Database className="h-3.5 w-3.5" />
                  PostgreSQL
                </div>
              </Row>
            </Section>

            {/* About */}
            <Section title="About" icon={Shield}>
              <Row>
                <div><p className="text-sm font-medium text-foreground">AI Model</p><p className="text-xs text-muted-foreground mt-0.5">Language model powering your conversations.</p></div>
                <span className="text-xs text-muted-foreground/60 font-mono bg-white/5 px-2.5 py-1 rounded-lg border border-white/8">GPT-4o</span>
              </Row>
              <Row>
                <div><p className="text-sm font-medium text-foreground">Image Generation</p><p className="text-xs text-muted-foreground mt-0.5">AI image generation model.</p></div>
                <span className="text-xs text-muted-foreground/60 font-mono bg-white/5 px-2.5 py-1 rounded-lg border border-white/8">DALL-E 3</span>
              </Row>
              <Row>
                <div><p className="text-sm font-medium text-foreground">Version</p></div>
                <span className="text-xs text-muted-foreground/50">2.0.0</span>
              </Row>
            </Section>
          </div>
        </div>
      </div>

      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent className="bg-card border-white/10 shadow-2xl rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Clear all conversations?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              This will permanently delete all {conversations?.length} conversation{conversations?.length !== 1 ? "s" : ""} from our servers. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-white/8 hover:bg-white/5 text-foreground">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleClearHistory} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isClearing ? "Deleting…" : "Yes, delete everything"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </ChatLayout>
  );
}
