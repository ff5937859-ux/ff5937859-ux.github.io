import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft, ArrowRight, Check, Clock3, RefreshCw, Sparkles, Vote,
  AlertTriangle, Ghost, Trophy,
} from "lucide-react";
import {
  getGetHalloweenVotesQueryKey,
  useGetHalloweenVotes,
  useSubmitHalloweenVote,
} from "@workspace/api-client-react";
import type { HalloweenVoteCount } from "@workspace/api-client-react";
import { useLanguage } from "@/context/LanguageContext";

type GameKey = "hunt" | "memory" | "reaction";
type HuntKind = "pumpkin" | "ghost" | "bat";
type MemoryKind = "pumpkin" | "ghost" | "bat" | "spider" | "skeleton" | "cauldron" | "candle" | "cat";
type MemoryCard = { id: string; kind: MemoryKind; matched: boolean; flipped: boolean };

const MEMORY_KINDS: MemoryKind[] = ["pumpkin", "ghost", "bat", "spider", "skeleton", "cauldron", "candle", "cat"];

const COPY = {
  es: {
    eyebrow: "UN PEQUEÑO DESVÍO ESTACIONAL", title: "La noche se acerca.",
    intro: "Juega un minuto, elige tus favoritos y vuelve a tu conversación.",
    countdown: "Cuenta atrás para Halloween", days: "días", hours: "horas", minutes: "min", seconds: "seg",
    halloweenToday: "¡Feliz Halloween!", nextHalloween: "La próxima noche empieza en",
    games: "Juegos breves", gamesNote: "Tres pequeñas pruebas. ¿Cuánto aguantas?",
    gameLabels: ["Caza calabazas", "Memoria nocturna", "Atrapa al fantasma"],
    playAgain: "Jugar de nuevo", best: "Récord", start: "Empezar",
    huntTitle: "Caza de calabazas", huntInstructions: "Calabaza +1 · Fantasma −1 · Murciélago neutral",
    huntStart: "Empezar la caza", huntDone: "Se acabó el tiempo.", points: "puntos",
    targetPumpkin: "Calabaza, un punto", targetGhost: "Fantasma, resta un punto", targetBat: "Murciélago, neutral",
    memoryTitle: "Memoria nocturna", memoryInstructions: "Encuentra las ocho parejas. Las cartas se mezclan en cada partida.",
    moves: "movimientos", elapsed: "tiempo", pairs: "parejas", memoryDone: "¡Todas las parejas encontradas!",
    reactionTitle: "Atrapa al fantasma", reactionInstructions: "Espera a que aparezca. Cada ronda va más rápido y el fantasma se hace más pequeño.",
    reactionStart: "Empezar reacción", wait: "Aún no… espera al fantasma", catch: "¡Atrápalo!",
    falseStart: "Demasiado pronto. Pulsa para volver a intentarlo.", round: "Ronda", nextRound: "Siguiente ronda",
    reactionDone: "¡Fantasma atrapado!", average: "tiempo medio", bestReaction: "mejor tiempo",
    trivia: "Trivia de medianoche", triviaIntro: "Cinco preguntas. Una sola oportunidad por pregunta.",
    question: "Pregunta", nextQuestion: "Siguiente pregunta", seeResult: "Ver resultado",
    correct: "¡Correcto!", incorrect: "No esta vez.", finalScore: "Tu resultado",
    triviaResults: ["La noche todavía guarda sus secretos.", "Buen comienzo, aprendiz nocturno.", "Ya conoces bien la noche.", "Eres leyenda de Halloween."],
    polls: "La votación de la noche", votes: "votos", cast: "Votar", change: "Cambiar voto",
    selected: "Tu elección", loading: "Buscando los resultados compartidos…",
    error: "No se pudieron cargar los votos compartidos.", retry: "Reintentar",
    voteError: "No se pudo guardar tu voto. Inténtalo de nuevo.",
    back: "Volver al chat", footer: "Una pausa breve. Tu espacio sigue siendo tuyo.",
    pollSet: [
      { question: "¿Qué disfraz elegirías?", options: ["Bruja", "Vampiro", "Fantasma", "Esqueleto"] },
      { question: "¿Truco o trato?", options: ["Truco", "Trato", "Ambos", "Fiesta"] },
      { question: "¿Qué tipo de terror prefieres?", options: ["Clásico", "Sobrenatural", "Slasher", "Familiar"] },
      { question: "¿Calabaza tallada o dulces?", options: ["Calabaza", "Caramelos", "Ambos", "Ninguno"] },
      { question: "¿Qué monstruo da más miedo?", options: ["Fantasma", "Vampiro", "Zombi", "Bruja"] },
      { question: "¿Tu dulce favorito?", options: ["Chocolate", "Manzana caramelizada", "Caramelos de maíz", "Otro"] },
    ],
    symbols: { pumpkin: "calabaza", ghost: "fantasma", bat: "murciélago", spider: "araña", skeleton: "esqueleto", cauldron: "caldero", candle: "vela", cat: "gato negro" },
    triviaSet: [
      { question: "¿Qué día se celebra Halloween?", options: ["30 de octubre", "31 de octubre", "1 de noviembre"], correct: 1 },
      { question: "¿Qué se talla tradicionalmente para hacer un jack-o'-lantern?", options: ["Una calabaza", "Una manzana", "Un nabo"], correct: 0 },
      { question: "¿Qué festividad celta se relaciona con el origen de Halloween?", options: ["Beltane", "Samhain", "Imbolc"], correct: 1 },
      { question: "¿Qué dos colores se asocian tradicionalmente con Halloween?", options: ["Azul y plata", "Rojo y blanco", "Naranja y negro"], correct: 2 },
      { question: "¿Quién escribió la novela Drácula?", options: ["Mary Shelley", "Bram Stoker", "Edgar Allan Poe"], correct: 1 },
    ],
  },
  en: {
    eyebrow: "A SEASONAL SIDE QUEST", title: "The night is getting closer.",
    intro: "Play for a minute, pick your favorites, then return to your conversation.",
    countdown: "Countdown to Halloween", days: "days", hours: "hours", minutes: "min", seconds: "sec",
    halloweenToday: "Happy Halloween!", nextHalloween: "The next Halloween night begins in",
    games: "Quick games", gamesNote: "Three little challenges. How far can you get?",
    gameLabels: ["Pumpkin hunt", "Midnight memory", "Catch the ghost"],
    playAgain: "Play again", best: "Best", start: "Start",
    huntTitle: "30-second pumpkin hunt", huntInstructions: "Pumpkin +1 · Ghost −1 · Bat is neutral",
    huntStart: "Start the hunt", huntDone: "Time is up.", points: "points",
    targetPumpkin: "Pumpkin, plus one", targetGhost: "Ghost, minus one", targetBat: "Bat, no points",
    memoryTitle: "Midnight memory", memoryInstructions: "Find all eight pairs. The deck shuffles every time.",
    moves: "moves", elapsed: "time", pairs: "pairs", memoryDone: "All pairs found!",
    reactionTitle: "Catch the ghost", reactionInstructions: "Wait until it appears. Each round gets quicker and the ghost gets smaller.",
    reactionStart: "Start reaction", wait: "Not yet… wait for the ghost", catch: "Catch it!",
    falseStart: "Too soon. Press to try again.", round: "Round", nextRound: "Next round",
    reactionDone: "Ghost caught!", average: "average time", bestReaction: "best time",
    trivia: "Midnight trivia", triviaIntro: "Five questions. One try for each.",
    question: "Question", nextQuestion: "Next question", seeResult: "See your score",
    correct: "That's right!", incorrect: "Not this time.", finalScore: "Your score",
    triviaResults: ["The night still keeps its secrets.", "A fine start, night apprentice.", "You know your Halloween lore.", "A Halloween legend."],
    polls: "Tonight's poll", votes: "votes", cast: "Vote", change: "Change vote",
    selected: "Your pick", loading: "Finding the shared results…",
    error: "Shared votes could not be loaded.", retry: "Try again",
    voteError: "Your vote could not be saved. Please try again.",
    back: "Back to chat", footer: "A brief detour. Your space is still yours.",
    pollSet: [
      { question: "Which costume would you choose?", options: ["Witch", "Vampire", "Ghost", "Skeleton"] },
      { question: "Trick or treat?", options: ["Trick", "Treat", "Both", "Party"] },
      { question: "What kind of horror movie do you like?", options: ["Classic", "Supernatural", "Slasher", "Family-friendly"] },
      { question: "Carved pumpkin or sweets?", options: ["Pumpkin", "Candy", "Both", "Neither"] },
      { question: "Which monster is scariest?", options: ["Ghost", "Vampire", "Zombie", "Witch"] },
      { question: "What is your favorite treat?", options: ["Chocolate", "Caramel apple", "Candy corn", "Other"] },
    ],
    symbols: { pumpkin: "pumpkin", ghost: "ghost", bat: "bat", spider: "spider", skeleton: "skeleton", cauldron: "cauldron", candle: "candle", cat: "black cat" },
    triviaSet: [
      { question: "On which date is Halloween celebrated?", options: ["October 30", "October 31", "November 1"], correct: 1 },
      { question: "What is traditionally carved to make a jack-o'-lantern?", options: ["A pumpkin", "An apple", "A turnip"], correct: 0 },
      { question: "Which Celtic festival is associated with Halloween's origins?", options: ["Beltane", "Samhain", "Imbolc"], correct: 1 },
      { question: "Which two colors are traditionally associated with Halloween?", options: ["Blue and silver", "Red and white", "Orange and black"], correct: 2 },
      { question: "Who wrote the novel Dracula?", options: ["Mary Shelley", "Bram Stoker", "Edgar Allan Poe"], correct: 1 },
    ],
  },
  ar: {
    eyebrow: "مغامرة موسمية قصيرة", title: "الليل يقترب.",
    intro: "العب لدقيقة، اختر مفضلاتك، ثم عد إلى محادثتك.",
    countdown: "العد التنازلي للهالوين", days: "أيام", hours: "ساعات", minutes: "دقيقة", seconds: "ثانية",
    halloweenToday: "هالوين سعيد!", nextHalloween: "الليلة التالية للهالوين تبدأ خلال",
    games: "ألعاب سريعة", gamesNote: "ثلاث تحديات صغيرة. إلى أي مدى ستصل؟",
    gameLabels: ["صيد القرع", "ذاكرة منتصف الليل", "أمسك الشبح"],
    playAgain: "العب مجدداً", best: "الأفضل", start: "ابدأ",
    huntTitle: "صيد القرع في 30 ثانية", huntInstructions: "القرع +1 · الشبح −1 · الخفاش بلا نقاط",
    huntStart: "ابدأ الصيد", huntDone: "انتهى الوقت.", points: "نقاط",
    targetPumpkin: "قرع، نقطة إضافية", targetGhost: "شبح، نقطة ناقصة", targetBat: "خفاش، بلا نقاط",
    memoryTitle: "ذاكرة منتصف الليل", memoryInstructions: "اعثر على الأزواج الثمانية. تتغير البطاقات في كل مرة.",
    moves: "حركات", elapsed: "الوقت", pairs: "أزواج", memoryDone: "تم العثور على كل الأزواج!",
    reactionTitle: "أمسك الشبح", reactionInstructions: "انتظر ظهوره. تصبح كل جولة أسرع والشبح أصغر.",
    reactionStart: "ابدأ اختبار السرعة", wait: "ليس بعد… انتظر الشبح", catch: "أمسكه!",
    falseStart: "مبكر جداً. اضغط للمحاولة مجدداً.", round: "الجولة", nextRound: "الجولة التالية",
    reactionDone: "تم الإمساك بالشبح!", average: "متوسط الوقت", bestReaction: "أفضل وقت",
    trivia: "أسئلة منتصف الليل", triviaIntro: "خمسة أسئلة. محاولة واحدة لكل سؤال.",
    question: "السؤال", nextQuestion: "السؤال التالي", seeResult: "اعرض نتيجتك",
    correct: "إجابة صحيحة!", incorrect: "ليست هذه المرة.", finalScore: "نتيجتك",
    triviaResults: ["ما زال الليل يخفي أسراره.", "بداية جيدة يا متدرب الليل.", "أنت تعرف حكايات الهالوين جيداً.", "أنت أسطورة الهالوين."],
    polls: "تصويت الليلة", votes: "أصوات", cast: "صوّت", change: "غيّر التصويت",
    selected: "اختيارك", loading: "جارٍ تحميل النتائج المشتركة…",
    error: "تعذّر تحميل الأصوات المشتركة.", retry: "أعد المحاولة",
    voteError: "تعذّر حفظ تصويتك. حاول مرة أخرى.",
    back: "العودة إلى المحادثة", footer: "استراحة قصيرة. مساحتك ما زالت لك.",
    pollSet: [
      { question: "أي زيّ ستختار؟", options: ["ساحرة", "مصاص دماء", "شبح", "هيكل عظمي"] },
      { question: "مقلب أم حلوى؟", options: ["مقلب", "حلوى", "كلاهما", "حفلة"] },
      { question: "ما نوع أفلام الرعب الذي تفضله؟", options: ["كلاسيكي", "خارق للطبيعة", "سفك الدماء", "عائلي"] },
      { question: "قرع منحوت أم حلويات؟", options: ["قرع", "حلوى", "كلاهما", "لا هذا ولا ذاك"] },
      { question: "أي وحش هو الأكثر رعباً؟", options: ["شبح", "مصاص دماء", "زومبي", "ساحرة"] },
      { question: "ما حلوى الهالوين المفضلة لديك؟", options: ["شوكولاتة", "تفاح بالكراميل", "حلوى الذرة", "أخرى"] },
    ],
    symbols: { pumpkin: "قرع", ghost: "شبح", bat: "خفاش", spider: "عنكبوت", skeleton: "هيكل عظمي", cauldron: "مرجل", candle: "شمعة", cat: "قطة سوداء" },
    triviaSet: [
      { question: "في أي تاريخ يُحتفل بالهالوين؟", options: ["30 أكتوبر", "31 أكتوبر", "1 نوفمبر"], correct: 1 },
      { question: "ما الشيء الذي يُنحت تقليدياً لصنع فانوس جاك؟", options: ["قرع", "تفاحة", "لفت"], correct: 0 },
      { question: "أي مهرجان كلتي يرتبط بأصول الهالوين؟", options: ["بيلتين", "سامهاين", "إمبولك"], correct: 1 },
      { question: "ما اللونان المرتبطان تقليدياً بالهالوين؟", options: ["الأزرق والفضي", "الأحمر والأبيض", "البرتقالي والأسود"], correct: 2 },
      { question: "من كتب رواية دراكولا؟", options: ["ماري شيلي", "برام ستوكر", "إدغار آلان بو"], correct: 1 },
    ],
  },
  zh: {
    eyebrow: "季节限定小支线", title: "夜色渐近。",
    intro: "玩上一分钟，选出你的最爱，然后回到对话中。",
    countdown: "距离万圣夜", days: "天", hours: "小时", minutes: "分钟", seconds: "秒",
    halloweenToday: "万圣节快乐！", nextHalloween: "距离下一次万圣夜还有",
    games: "快速小游戏", gamesNote: "三个小挑战，看看你能玩到哪一步。",
    gameLabels: ["南瓜寻踪", "午夜记忆", "抓住幽灵"],
    playAgain: "再玩一次", best: "最佳", start: "开始",
    huntTitle: "30 秒南瓜寻踪", huntInstructions: "南瓜 +1 · 幽灵 −1 · 蝙蝠不计分",
    huntStart: "开始寻找", huntDone: "时间到。", points: "分",
    targetPumpkin: "南瓜，加一分", targetGhost: "幽灵，减一分", targetBat: "蝙蝠，不计分",
    memoryTitle: "午夜记忆", memoryInstructions: "找出八组配对。每次开始都会重新洗牌。",
    moves: "步数", elapsed: "用时", pairs: "组配对", memoryDone: "所有配对都找到了！",
    reactionTitle: "抓住幽灵", reactionInstructions: "等它出现再抓。每一轮都会更快，幽灵也会变小。",
    reactionStart: "开始反应挑战", wait: "还没出现…等等幽灵", catch: "抓住它！",
    falseStart: "太早了。点击后再试一次。", round: "第", nextRound: "下一轮",
    reactionDone: "抓到幽灵了！", average: "平均用时", bestReaction: "最佳用时",
    trivia: "午夜问答", triviaIntro: "五道题，每题只有一次作答机会。",
    question: "第", nextQuestion: "下一题", seeResult: "查看成绩",
    correct: "答对了！", incorrect: "这次不对。", finalScore: "你的成绩",
    triviaResults: ["夜晚还有许多秘密。", "不错的开始，夜行学徒。", "你很懂万圣节传说。", "你是万圣节传奇。"],
    polls: "今晚投票", votes: "票", cast: "投票", change: "更改选择",
    selected: "你的选择", loading: "正在获取共享结果…",
    error: "无法加载共享投票。", retry: "重试",
    voteError: "无法保存你的投票，请重试。",
    back: "返回聊天", footer: "短暂绕行，你的空间依然属于你。",
    pollSet: [
      { question: "你会选择哪种装扮？", options: ["女巫", "吸血鬼", "幽灵", "骷髅"] },
      { question: "不给糖就捣蛋？", options: ["捣蛋", "要糖", "都要", "派对"] },
      { question: "你喜欢哪种恐怖片？", options: ["经典", "超自然", "血腥", "家庭向"] },
      { question: "雕刻南瓜还是糖果？", options: ["南瓜", "糖果", "都喜欢", "都不要"] },
      { question: "哪种怪物最可怕？", options: ["幽灵", "吸血鬼", "僵尸", "女巫"] },
      { question: "你最喜欢哪种甜食？", options: ["巧克力", "焦糖苹果", "玉米糖", "其他"] },
    ],
    symbols: { pumpkin: "南瓜", ghost: "幽灵", bat: "蝙蝠", spider: "蜘蛛", skeleton: "骷髅", cauldron: "坩埚", candle: "蜡烛", cat: "黑猫" },
    triviaSet: [
      { question: "万圣节是几月几日？", options: ["10月30日", "10月31日", "11月1日"], correct: 1 },
      { question: "制作杰克灯通常会雕刻什么？", options: ["南瓜", "苹果", "芜菁"], correct: 0 },
      { question: "哪一个凯尔特节日与万圣节起源有关？", options: ["贝尔丹火节", "萨温节", "因博克节"], correct: 1 },
      { question: "哪两种颜色通常与万圣节相关？", options: ["蓝色和银色", "红色和白色", "橙色和黑色"], correct: 2 },
      { question: "小说《德古拉》的作者是谁？", options: ["玛丽·雪莱", "布拉姆·斯托克", "埃德加·爱伦·坡"], correct: 1 },
    ],
  },
  ja: {
    eyebrow: "季節限定の小さな寄り道", title: "夜が近づいています。",
    intro: "少し遊んで、好きなものを選んだら、会話に戻りましょう。",
    countdown: "ハロウィンまで", days: "日", hours: "時間", minutes: "分", seconds: "秒",
    halloweenToday: "ハッピーハロウィン！", nextHalloween: "次のハロウィンまで",
    games: "ミニゲーム", gamesNote: "3つの小さなチャレンジ。どこまで進める？",
    gameLabels: ["カボチャ探し", "真夜中の記憶", "ゴーストを捕まえる"],
    playAgain: "もう一度遊ぶ", best: "ベスト", start: "スタート",
    huntTitle: "30秒カボチャ探し", huntInstructions: "カボチャ +1 · ゴースト −1 · コウモリは得点なし",
    huntStart: "探し始める", huntDone: "時間切れです。", points: "点",
    targetPumpkin: "カボチャ、プラス1", targetGhost: "ゴースト、マイナス1", targetBat: "コウモリ、得点なし",
    memoryTitle: "真夜中の記憶", memoryInstructions: "8組のペアを見つけよう。毎回カードがシャッフルされます。",
    moves: "手数", elapsed: "時間", pairs: "ペア", memoryDone: "すべてのペアを発見！",
    reactionTitle: "ゴーストを捕まえる", reactionInstructions: "現れるまで待って。ラウンドごとに速く、小さくなります。",
    reactionStart: "反応ゲーム開始", wait: "まだ…ゴーストを待って", catch: "捕まえて！",
    falseStart: "早すぎます。押してもう一度。", round: "ラウンド", nextRound: "次のラウンド",
    reactionDone: "ゴーストを捕まえた！", average: "平均タイム", bestReaction: "ベストタイム",
    trivia: "真夜中のクイズ", triviaIntro: "全5問。各問題に答えられるのは1回だけ。",
    question: "問題", nextQuestion: "次の問題", seeResult: "結果を見る",
    correct: "正解！", incorrect: "残念。", finalScore: "スコア",
    triviaResults: ["夜にはまだ秘密が隠れています。", "いいスタート、夜の見習いさん。", "ハロウィンの物語に詳しいですね。", "ハロウィンの伝説です。"],
    polls: "今夜の投票", votes: "票", cast: "投票する", change: "投票を変更",
    selected: "あなたの選択", loading: "共有結果を読み込み中…",
    error: "共有投票を読み込めませんでした。", retry: "再試行",
    voteError: "投票を保存できませんでした。もう一度お試しください。",
    back: "チャットに戻る", footer: "短い寄り道。あなたの場所はそのままです。",
    pollSet: [
      { question: "どの仮装を選ぶ？", options: ["魔女", "吸血鬼", "幽霊", "骸骨"] },
      { question: "トリック・オア・トリート？", options: ["いたずら", "お菓子", "両方", "パーティー"] },
      { question: "どんなホラー映画が好き？", options: ["古典", "超自然", "スラッシャー", "ファミリー向け"] },
      { question: "彫ったカボチャ、それともお菓子？", options: ["カボチャ", "キャンディ", "両方", "どちらでもない"] },
      { question: "一番怖いモンスターは？", options: ["幽霊", "吸血鬼", "ゾンビ", "魔女"] },
      { question: "一番好きなお菓子は？", options: ["チョコレート", "キャラメルアップル", "キャンディコーン", "その他"] },
    ],
    symbols: { pumpkin: "カボチャ", ghost: "ゴースト", bat: "コウモリ", spider: "クモ", skeleton: "骸骨", cauldron: "大釜", candle: "ろうそく", cat: "黒猫" },
    triviaSet: [
      { question: "ハロウィンは何月何日？", options: ["10月30日", "10月31日", "11月1日"], correct: 1 },
      { question: "ジャック・オー・ランタンに使うものは？", options: ["カボチャ", "リンゴ", "カブ"], correct: 0 },
      { question: "ハロウィンの起源に関係するケルトのお祭りは？", options: ["ベルテーン", "サウィン", "インボルク"], correct: 1 },
      { question: "ハロウィンに伝統的に結びつく色は？", options: ["青と銀", "赤と白", "オレンジと黒"], correct: 2 },
      { question: "小説『ドラキュラ』を書いたのは誰？", options: ["メアリー・シェリー", "ブラム・ストーカー", "エドガー・アラン・ポー"], correct: 1 },
    ],
  },
} as const;

const POLLS = [
  { id: "halloween-q1", options: ["q1-witch", "q1-vampire", "q1-ghost", "q1-skeleton"] },
  { id: "halloween-q2", options: ["q2-trick", "q2-treat", "q2-both", "q2-party"] },
  { id: "halloween-q3", options: ["q3-classic", "q3-supernatural", "q3-slasher", "q3-family"] },
  { id: "halloween-q4", options: ["q4-pumpkin", "q4-candy", "q4-both", "q4-neither"] },
  { id: "halloween-q5", options: ["q5-ghost", "q5-vampire", "q5-zombie", "q5-witch"] },
  { id: "halloween-q6", options: ["q6-chocolate", "q6-caramel-apple", "q6-candy-corn", "q6-other"] },
];

function HalloweenGlyph({ kind, className = "" }: { kind: MemoryKind | HuntKind; className?: string }) {
  if (kind === "ghost") return <Ghost className={className} strokeWidth={1.6} aria-hidden="true" />;
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" aria-hidden="true">
      {kind === "pumpkin" && (
        <>
          <path d="M22 10c-2-3-.3-5.7 4-6-.1 3-1.3 4.8-4 6Z" fill="currentColor" />
          <path d="M24 12c-4-3-8-2.5-11.4.3-6.2 5-6.8 18.7.2 23.8 2.4 1.8 5.3 1.8 8.3.7 1.9 1.1 3.9 1.1 5.8 0 3 1.1 5.9 1.1 8.3-.7 7-5.1 6.4-18.8.2-23.8C32 9.5 28 9 24 12Z" stroke="currentColor" strokeWidth="2.2" />
          <path d="m15 19 5 4-5 4m18-8-5 4 5 4m-9-6v9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </>
      )}
      {kind === "bat" && <path d="M5 18 3 9l10 6c3-4 7-6 11-6s8 2 11 6l10-6-2 9 2 13-11-7-10 8-10-8-11 7 2-13Z" fill="currentColor" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />}
      {kind === "spider" && (
        <>
          <circle cx="24" cy="24" r="7" fill="currentColor" />
          <circle cx="24" cy="13" r="4" fill="currentColor" />
          <path d="m18 21-8-6m7 11-9 2m11 3-7 8m18-17 8-6m-7 11 9 2m-11 3 7 8M20 12l-5-6m13 6 5-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </>
      )}
      {kind === "skeleton" && (
        <>
          <path d="M24 5a13 13 0 0 0-8 23v6h16v-6a13 13 0 0 0-8-23Z" stroke="currentColor" strokeWidth="2.2" />
          <circle cx="19" cy="18" r="3" fill="currentColor" /><circle cx="29" cy="18" r="3" fill="currentColor" />
          <path d="m22 25 2-3 2 3m-6 8v5m4-5v6m4-6v5m-14 1h20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </>
      )}
      {kind === "cauldron" && (
        <>
          <path d="M10 20h28l-3 15a5 5 0 0 1-5 4H18a5 5 0 0 1-5-4l-3-15Z" fill="currentColor" fillOpacity=".17" stroke="currentColor" strokeWidth="2.2" />
          <path d="M8 20h32M17 39l-3 4m17-4 3 4M18 15c-2-3 2-4 0-7m8 7c-2-3 2-4 0-7m8 7c-2-3 2-4 0-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </>
      )}
      {kind === "candle" && (
        <>
          <path d="M17 20h14v23H17z" fill="currentColor" fillOpacity=".18" stroke="currentColor" strokeWidth="2" />
          <path d="M24 5c-6 6-4 11 0 13 4-3 6-7 0-13Zm0 15v-3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M21 27h6m-6 6h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
        </>
      )}
      {kind === "cat" && (
        <>
          <path d="m10 18-1-11 10 6a17 17 0 0 1 10 0l10-6-1 11c3 5 3 12-1 17-3 4-7 6-12 6s-9-2-12-6c-4-5-4-12-1-17Z" fill="currentColor" fillOpacity=".15" stroke="currentColor" strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M17 25h.1m13 0h.1M21 31l3 2 3-2m-3-2v2m-10 0-5 1m24-1 5 1" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
        </>
      )}
    </svg>
  );
}

function readRecord(key: string) {
  try {
    const value = Number(localStorage.getItem(key) || 0);
    return Number.isFinite(value) && value >= 0 ? value : 0;
  } catch { return 0; }
}

function saveRecord(key: string, value: number, lowerIsBetter = false) {
  const current = readRecord(key);
  const shouldSave = current === 0 || (lowerIsBetter ? value < current : value > current);
  if (shouldSave) {
    try { localStorage.setItem(key, String(value)); } catch { /* Scores remain playable without storage. */ }
    return value;
  }
  return current;
}

function makeMemoryDeck(): MemoryCard[] {
  return [...MEMORY_KINDS, ...MEMORY_KINDS]
    .map((kind, index) => ({ kind, id: `${kind}-${index}-${Math.random().toString(36).slice(2, 7)}`, matched: false, flipped: false }))
    .sort(() => Math.random() - 0.5);
}

function makeHuntTarget() {
  const kinds: HuntKind[] = ["pumpkin", "ghost", "bat"];
  return {
    kind: kinds[Math.floor(Math.random() * kinds.length)],
    left: 8 + Math.random() * 78,
    top: 9 + Math.random() * 68,
    id: `${Date.now()}-${Math.random()}`,
  };
}

function getVoterToken() {
  const key = "chatia-voter-token";
  try {
    let token = localStorage.getItem(key);
    if (!token) {
      token = typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `${Math.random().toString(36).slice(2)}${Date.now()}`;
      localStorage.setItem(key, token);
    }
    return token;
  } catch {
    return `session-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }
}

export default function Halloween() {
  const { language: appLanguage } = useLanguage();
  const [language, setLanguage] = useState<keyof typeof COPY>(() => {
    try {
      const saved = localStorage.getItem("chatai-language");
      return saved && saved in COPY ? saved as keyof typeof COPY : "es";
    } catch { return "es"; }
  });
  const [now, setNow] = useState(() => Date.now());
  const [activeGame, setActiveGame] = useState<GameKey>("hunt");

  const [huntRunning, setHuntRunning] = useState(false);
  const [huntTime, setHuntTime] = useState(30);
  const [huntScore, setHuntScore] = useState(0);
  const [huntTarget, setHuntTarget] = useState(makeHuntTarget);
  const [huntBest, setHuntBest] = useState(() => readRecord("chatia-halloween-best-hunt"));

  const [memoryCards, setMemoryCards] = useState(makeMemoryDeck);
  const [memoryOpen, setMemoryOpen] = useState<number[]>([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memoryElapsed, setMemoryElapsed] = useState(0);
  const [memoryStarted, setMemoryStarted] = useState(false);
  const [memoryDone, setMemoryDone] = useState(false);
  const [memoryBest, setMemoryBest] = useState(() => readRecord("chatia-halloween-best-memory"));
  const memoryTimeout = useRef<number | null>(null);

  const [reactionStatus, setReactionStatus] = useState<"idle" | "waiting" | "ready" | "result" | "done">("idle");
  const [reactionRound, setReactionRound] = useState(1);
  const [reactionTimes, setReactionTimes] = useState<number[]>([]);
  const [reactionMessage, setReactionMessage] = useState("");
  const [reactionPosition, setReactionPosition] = useState({ left: 50, top: 50 });
  const [reactionBest, setReactionBest] = useState(() => readRecord("chatia-halloween-best-reaction"));
  const reactionTimeout = useRef<number | null>(null);
  const readyAt = useRef(0);

  const [triviaIndex, setTriviaIndex] = useState(0);
  const [triviaScore, setTriviaScore] = useState(0);
  const [triviaChoice, setTriviaChoice] = useState<number | null>(null);
  const [triviaFinished, setTriviaFinished] = useState(false);

  const [activePoll, setActivePoll] = useState(0);
  const [myVote, setMyVote] = useState<string | null>(null);
  const [lastVoteAttempt, setLastVoteAttempt] = useState<string | null>(null);

  const queryClient = useQueryClient();
  const copy = COPY[language];
  const activeQuestion = POLLS[activePoll];

  useEffect(() => {
    try {
      const saved = localStorage.getItem("chatai-language");
      if (saved && saved in COPY) setLanguage(appLanguage as keyof typeof COPY);
    } catch { /* Spanish remains the seasonal default when storage is unavailable. */ }
  }, [appLanguage]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const halloweenToday = (() => {
    const date = new Date(now);
    return date.getMonth() === 9 && date.getDate() === 31;
  })();

  const countdown = useMemo(() => {
    const current = new Date(now);
    const thisYearTarget = new Date(current.getFullYear(), 9, 31);
    const targetYear = thisYearTarget.getTime() > now ? current.getFullYear() : current.getFullYear() + 1;
    const target = new Date(targetYear, 9, 31);
    const remaining = Math.max(0, target.getTime() - now);
    return {
      days: Math.floor(remaining / 86_400_000),
      hours: Math.floor((remaining % 86_400_000) / 3_600_000),
      minutes: Math.floor((remaining % 3_600_000) / 60_000),
      seconds: Math.floor((remaining % 60_000) / 1000),
    };
  }, [now]);

  const votesQuery = useGetHalloweenVotes(activeQuestion.id, {
    query: { enabled: !!activeQuestion.id, queryKey: getGetHalloweenVotesQueryKey(activeQuestion.id), retry: 1 },
  });
  const submitVote = useSubmitHalloweenVote();
  const voteRows = votesQuery.data ?? [];
  const totalVotes = voteRows.reduce((sum, row) => sum + row.count, 0);

  useEffect(() => {
    try { setMyVote(localStorage.getItem(`chatia-halloween-vote-${activeQuestion.id}`)); }
    catch { setMyVote(null); }
  }, [activeQuestion.id]);

  useEffect(() => {
    if (!huntRunning) return;
    const secondTimer = window.setInterval(() => setHuntTime((time) => Math.max(0, time - 1)), 1000);
    const spawnTimer = window.setInterval(() => setHuntTarget(makeHuntTarget()), 780);
    return () => { window.clearInterval(secondTimer); window.clearInterval(spawnTimer); };
  }, [huntRunning]);

  useEffect(() => {
    if (huntTime === 0 && huntRunning) setHuntRunning(false);
  }, [huntTime, huntRunning]);

  useEffect(() => {
    if (huntTime === 0 && !huntRunning) setHuntBest((best) => saveRecord("chatia-halloween-best-hunt", huntScore) > best ? huntScore : best);
  }, [huntTime, huntRunning, huntScore]);

  useEffect(() => {
    if (!memoryStarted || memoryDone) return;
    const timer = window.setInterval(() => setMemoryElapsed((time) => time + 1), 1000);
    return () => window.clearInterval(timer);
  }, [memoryStarted, memoryDone]);

  useEffect(() => () => {
    if (memoryTimeout.current !== null) window.clearTimeout(memoryTimeout.current);
    if (reactionTimeout.current !== null) window.clearTimeout(reactionTimeout.current);
  }, []);

  const startHunt = () => {
    setHuntScore(0);
    setHuntTime(30);
    setHuntTarget(makeHuntTarget());
    setHuntRunning(true);
  };

  const hitHuntTarget = (kind: HuntKind) => {
    if (!huntRunning) return;
    if (kind === "pumpkin") setHuntScore((score) => score + 1);
    if (kind === "ghost") setHuntScore((score) => score - 1);
    setHuntTarget(makeHuntTarget());
  };

  const restartMemory = () => {
    if (memoryTimeout.current !== null) window.clearTimeout(memoryTimeout.current);
    setMemoryCards(makeMemoryDeck());
    setMemoryOpen([]);
    setMemoryMoves(0);
    setMemoryElapsed(0);
    setMemoryStarted(false);
    setMemoryDone(false);
  };

  const selectMemoryCard = (index: number) => {
    if (memoryDone || memoryOpen.length >= 2 || memoryCards[index].matched || memoryCards[index].flipped) return;
    setMemoryStarted(true);
    const opened = [...memoryOpen, index];
    const nextCards = memoryCards.map((card, cardIndex) => cardIndex === index ? { ...card, flipped: true } : card);
    setMemoryCards(nextCards);
    setMemoryOpen(opened);
    if (opened.length === 2) {
      const [first, second] = opened;
      const nextMoves = memoryMoves + 1;
      setMemoryMoves(nextMoves);
      if (nextCards[first].kind === nextCards[second].kind) {
        const matchedCards = nextCards.map((card, cardIndex) => opened.includes(cardIndex) ? { ...card, matched: true } : card);
        setMemoryCards(matchedCards);
        setMemoryOpen([]);
        if (matchedCards.every((card) => card.matched)) {
          setMemoryDone(true);
          setMemoryBest((best) => saveRecord("chatia-halloween-best-memory", nextMoves, true) < best || best === 0 ? nextMoves : best);
        }
      } else {
        memoryTimeout.current = window.setTimeout(() => {
          setMemoryCards((cards) => cards.map((card, cardIndex) => opened.includes(cardIndex) ? { ...card, flipped: false } : card));
          setMemoryOpen([]);
          memoryTimeout.current = null;
        }, 760);
      }
    }
  };

  const startReactionRound = (round: number) => {
    if (reactionTimeout.current !== null) window.clearTimeout(reactionTimeout.current);
    setReactionRound(round);
    setReactionStatus("waiting");
    setReactionMessage("");
    const delay = Math.max(520, 1800 - (round - 1) * 260 + Math.random() * 520);
    reactionTimeout.current = window.setTimeout(() => {
      setReactionPosition({ left: 14 + Math.random() * 70, top: 16 + Math.random() * 56 });
      readyAt.current = performance.now();
      setReactionStatus("ready");
    }, delay);
  };

  const reactionClick = () => {
    if (reactionStatus === "idle" || reactionStatus === "done") return;
    if (reactionStatus === "waiting") {
      if (reactionTimeout.current !== null) window.clearTimeout(reactionTimeout.current);
      setReactionStatus("result");
      setReactionMessage(copy.falseStart);
      return;
    }
    if (reactionStatus !== "ready") return;
    const reaction = Math.round(performance.now() - readyAt.current);
    const times = [...reactionTimes, reaction];
    setReactionTimes(times);
    if (reactionRound >= 5) {
      const average = Math.round(times.reduce((sum, time) => sum + time, 0) / times.length);
      setReactionStatus("done");
      setReactionBest((best) => {
        const saved = saveRecord("chatia-halloween-best-reaction", average, true);
        return saved < best || best === 0 ? average : best;
      });
    } else {
      setReactionStatus("result");
      setReactionMessage(`${reaction} ms`);
    }
  };

  const resetReaction = () => {
    if (reactionTimeout.current !== null) window.clearTimeout(reactionTimeout.current);
    setReactionStatus("idle");
    setReactionRound(1);
    setReactionTimes([]);
    setReactionMessage("");
  };

  const answerTrivia = (choice: number) => {
    if (triviaChoice !== null || triviaFinished) return;
    setTriviaChoice(choice);
    if (choice === copy.triviaSet[triviaIndex].correct) setTriviaScore((score) => score + 1);
  };

  const advanceTrivia = () => {
    if (triviaIndex === copy.triviaSet.length - 1) {
      setTriviaFinished(true);
      return;
    }
    setTriviaIndex((index) => index + 1);
    setTriviaChoice(null);
  };

  const restartTrivia = () => {
    setTriviaIndex(0);
    setTriviaScore(0);
    setTriviaChoice(null);
    setTriviaFinished(false);
  };

  const castVote = (optionId: string) => {
    setLastVoteAttempt(optionId);
    submitVote.mutate(
      { data: { questionId: activeQuestion.id, optionId, voterToken: getVoterToken() } },
      {
        onSuccess: (rows: HalloweenVoteCount[]) => {
          setMyVote(optionId);
          try { localStorage.setItem(`chatia-halloween-vote-${activeQuestion.id}`, optionId); } catch { /* API remains authoritative. */ }
          queryClient.setQueryData(getGetHalloweenVotesQueryKey(activeQuestion.id), rows);
        },
      },
    );
  };

  const resultIndex = triviaScore <= 1 ? 0 : triviaScore <= 3 ? 1 : triviaScore === 4 ? 2 : 3;

  return (
    <main className="halloween-page halloween-grain min-h-[100dvh] overflow-hidden text-foreground">
      <div className="relative z-[1] mx-auto w-full max-w-6xl px-4 pb-12 pt-5 sm:px-7 md:px-10">
        <header className="mb-8 flex items-center justify-between">
          <Link href="/chat" className="halloween-focus inline-flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> {copy.back}
          </Link>
          <div className="flex items-center gap-2 text-[10px] font-semibold tracking-[.2em] text-orange-200/70">
            <span className="h-1.5 w-1.5 rounded-full bg-orange-300" /> OMNI / AFTER DARK
          </div>
        </header>

        <section className={`relative mb-6 overflow-hidden rounded-[2rem] border border-orange-200/10 bg-[#19151d]/85 px-6 py-8 sm:px-10 sm:py-10 ${halloweenToday ? "halloween-celebrate" : ""}`}>
          <div className="pointer-events-none absolute inset-0 opacity-50" aria-hidden="true">
            <div className="absolute -right-6 -top-24 h-64 w-64 rounded-full border border-orange-200/10" />
            <div className="absolute -right-1 -top-20 h-52 w-52 rounded-full border border-violet-200/10" />
            <svg className="h-full w-full" viewBox="0 0 1000 360" preserveAspectRatio="xMidYMax slice">
              <path d="M0 330h1000M0 350h1000M135 320v-72h28v72m-20-72v-30h12v30m38 102V210h90v110m-70-110v-42h50v42m76 150V260h82v60m-72-60v-40h22v40m430 60V235h90v85m-65-85v-36h40v36m70 121V200h60v120m-44-120v-35h25v35" fill="none" stroke="rgba(248,150,83,.18)" strokeWidth="2" />
            </svg>
            {halloweenToday && <div className="halloween-confetti absolute inset-0">{Array.from({ length: 18 }, (_, index) => <span key={index} style={{ left: `${(index * 37) % 100}%`, animationDelay: `${(index % 6) * -.55}s`, animationDuration: `${4 + index % 4}s` }}><HalloweenGlyph kind="pumpkin" className="h-4 w-4 text-orange-200/70" /></span>)}</div>}
          </div>
          <div className="relative grid items-end gap-8 lg:grid-cols-[1fr_auto]">
            <div className="max-w-2xl">
              <p className="mb-5 flex items-center gap-2 text-[10px] font-semibold tracking-[.25em] text-orange-200/65">
                <Sparkles className="h-3.5 w-3.5" /> {copy.eyebrow}
              </p>
              <h1 className="font-serif text-4xl font-semibold leading-[1.05] tracking-[-.04em] text-orange-50 sm:text-6xl">
                {halloweenToday ? copy.halloweenToday : copy.title}
              </h1>
              <p className="mt-4 max-w-lg text-sm leading-7 text-muted-foreground sm:text-base">{copy.intro}</p>
            </div>
            <div className="halloween-card relative min-w-[250px] rounded-2xl px-5 py-4">
              <div className="mb-3 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.18em] text-violet-200/65">
                <Clock3 className="h-3.5 w-3.5" /> {halloweenToday ? copy.nextHalloween : copy.countdown}
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                {[
                  [countdown.days, copy.days],
                  [countdown.hours, copy.hours],
                  [countdown.minutes, copy.minutes],
                  [countdown.seconds, copy.seconds],
                ].map(([value, label]) => (
                  <div key={String(label)}>
                    <div className="font-mono text-xl font-semibold tabular-nums text-orange-100 sm:text-2xl">{String(value).padStart(2, "0")}</div>
                    <div className="mt-1 text-[9px] text-muted-foreground">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1.12fr_.88fr]">
          <section className="halloween-card rounded-[1.75rem] p-5 sm:p-7" aria-labelledby="games-heading">
            <div className="mb-5 flex items-end justify-between gap-4">
              <div>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[.2em] text-violet-200/55">01 / PLAY</p>
                <h2 id="games-heading" className="font-serif text-2xl text-foreground">{copy.games}</h2>
                <p className="mt-1 text-xs text-muted-foreground">{copy.gamesNote}</p>
              </div>
              <Trophy className="mb-1 h-4 w-4 text-orange-200/55" />
            </div>

            <div className="mb-5 grid grid-cols-3 gap-1.5 rounded-xl border border-white/[.06] bg-black/15 p-1">
              {copy.gameLabels.map((label, index) => {
                const game: GameKey = index === 0 ? "hunt" : index === 1 ? "memory" : "reaction";
                return (
                  <button
                    type="button"
                    key={game}
                    aria-pressed={activeGame === game}
                    onClick={() => setActiveGame(game)}
                    className={`halloween-focus rounded-lg px-2 py-2.5 text-[11px] leading-tight transition-colors sm:text-xs ${activeGame === game ? "bg-orange-200/10 text-orange-100" : "text-muted-foreground hover:bg-white/[.04] hover:text-foreground"}`}
                  >{label}</button>
                );
              })}
            </div>

            {activeGame === "hunt" && (
              <div className="rounded-2xl border border-white/[.07] bg-black/15 p-4 sm:p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-semibold">{copy.huntTitle}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{copy.huntInstructions}</p>
                  </div>
                  <div className="text-right text-[10px] text-muted-foreground">{copy.best}<div className="font-mono text-sm text-orange-200">{huntBest}</div></div>
                </div>
                <div className="mt-4 flex items-center justify-between rounded-xl border border-white/[.05] bg-white/[.025] px-3 py-2 text-xs">
                  <span className="font-mono text-orange-100" aria-live="polite">{huntTime}s</span>
                  <span className="font-mono text-foreground">{huntScore} {copy.points}</span>
                </div>
                <div className="relative mt-3 h-56 overflow-hidden rounded-xl border border-orange-200/[.08] bg-[radial-gradient(ellipse_at_50%_110%,rgba(152,82,46,.17),transparent_55%)] sm:h-64">
                  {huntRunning ? (
                    <button
                      key={huntTarget.id}
                      type="button"
                      onClick={() => hitHuntTarget(huntTarget.kind)}
                      aria-label={huntTarget.kind === "pumpkin" ? copy.targetPumpkin : huntTarget.kind === "ghost" ? copy.targetGhost : copy.targetBat}
                      className={`halloween-focus absolute -translate-x-1/2 -translate-y-1/2 rounded-full p-3 transition-transform active:scale-90 ${huntTarget.kind === "pumpkin" ? "text-orange-200" : huntTarget.kind === "ghost" ? "text-violet-100" : "text-muted-foreground"}`}
                      style={{ left: `${huntTarget.left}%`, top: `${huntTarget.top}%` }}
                    ><HalloweenGlyph kind={huntTarget.kind} className="h-9 w-9" /></button>
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center">
                      {huntTime === 0 && <p className="text-sm text-muted-foreground">{copy.huntDone} <span className="text-orange-100">{huntScore} {copy.points}</span></p>}
                      <button type="button" onClick={startHunt} className="halloween-focus rounded-full border border-orange-200/20 bg-orange-200/[.07] px-4 py-2 text-xs text-orange-100 transition-colors hover:bg-orange-200/[.13]">{huntTime === 30 ? copy.huntStart : copy.playAgain}</button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeGame === "memory" && (
              <div className="rounded-2xl border border-white/[.07] bg-black/15 p-4 sm:p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-semibold">{copy.memoryTitle}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{copy.memoryInstructions}</p>
                  </div>
                  <button type="button" aria-label={copy.playAgain} onClick={restartMemory} className="halloween-focus rounded-lg p-2 text-muted-foreground hover:bg-white/[.05] hover:text-orange-100"><RefreshCw className="h-4 w-4" /></button>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-muted-foreground">
                  <span>{copy.moves}: <strong className="font-mono text-orange-100">{memoryMoves}</strong></span>
                  <span>{copy.elapsed}: <strong className="font-mono text-orange-100">{memoryElapsed}s</strong></span>
                  <span>{copy.best}: <strong className="font-mono text-orange-100">{memoryBest || "—"}</strong> {memoryBest ? copy.moves : ""}</span>
                </div>
                <div className="mt-4 grid grid-cols-4 gap-2 sm:gap-2.5">
                  {memoryCards.map((card, index) => {
                    const visible = card.flipped || card.matched;
                    return (
                      <button
                        type="button"
                        key={card.id}
                        onClick={() => selectMemoryCard(index)}
                        disabled={card.matched || (memoryOpen.length === 2 && !card.flipped)}
                        aria-label={visible ? copy.symbols[card.kind] : `${copy.gameLabels[1]} ${index + 1}`}
                        aria-pressed={visible}
                        className={`halloween-focus flex aspect-square items-center justify-center rounded-xl border transition-colors ${visible ? "border-orange-200/20 bg-orange-200/[.07] text-orange-100" : "border-violet-200/[.12] bg-violet-200/[.025] text-violet-200/70 hover:bg-violet-200/[.08]"}`}
                      >
                        {visible ? <HalloweenGlyph kind={card.kind} className="h-7 w-7 sm:h-8 sm:w-8" /> : <span className="font-serif text-lg text-violet-100/45">?</span>}
                      </button>
                    );
                  })}
                </div>
                {memoryDone && <p className="mt-4 flex items-center gap-2 text-xs text-orange-100" aria-live="polite"><Check className="h-4 w-4" />{copy.memoryDone} · {memoryMoves} {copy.moves} · {memoryElapsed}s</p>}
              </div>
            )}

            {activeGame === "reaction" && (
              <div className="rounded-2xl border border-white/[.07] bg-black/15 p-4 sm:p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-semibold">{copy.reactionTitle}</h3>
                    <p className="mt-1 text-xs leading-5 text-muted-foreground">{copy.reactionInstructions}</p>
                  </div>
                  <div className="text-right text-[10px] text-muted-foreground">{copy.bestReaction}<div className="font-mono text-sm text-orange-200">{reactionBest ? `${reactionBest} ms` : "—"}</div></div>
                </div>
                <div className="mt-4 flex items-center justify-between rounded-xl border border-white/[.05] bg-white/[.025] px-3 py-2 text-xs text-muted-foreground">
                  <span>{copy.round} {reactionRound}/5</span>
                  <span>{reactionTimes.length ? `${reactionTimes.at(-1)} ms` : ""}</span>
                </div>
                <div className={`relative mt-3 h-56 overflow-hidden rounded-xl border border-violet-200/[.08] ${reactionStatus === "ready" ? "bg-orange-200/[.055]" : "bg-black/10"} sm:h-64`}>
                  {reactionStatus === "ready" ? (
                    <button
                      type="button"
                      onClick={reactionClick}
                      aria-label={copy.catch}
                      className="halloween-focus absolute rounded-full p-2 text-violet-100"
                      style={{ left: `${reactionPosition.left}%`, top: `${reactionPosition.top}%`, transform: `translate(-50%, -50%) scale(${Math.max(.45, 1 - (reactionRound - 1) * .12)})` }}
                    ><Ghost className="h-12 w-12" strokeWidth={1.3} /></button>
                  ) : reactionStatus === "waiting" ? (
                    <button type="button" onClick={reactionClick} className="halloween-focus absolute inset-0 grid place-items-center text-sm text-muted-foreground">{copy.wait}</button>
                  ) : reactionStatus === "idle" ? (
                    <button type="button" onClick={() => { setReactionTimes([]); startReactionRound(1); }} className="halloween-focus absolute inset-0 grid place-items-center text-sm text-orange-100">{copy.reactionStart}</button>
                  ) : reactionStatus === "done" ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-center">
                      <p className="text-sm text-orange-100">{copy.reactionDone}</p>
                      <p className="text-xs text-muted-foreground">{copy.average}: {Math.round(reactionTimes.reduce((sum, time) => sum + time, 0) / Math.max(1, reactionTimes.length))} ms</p>
                      <button type="button" onClick={resetReaction} className="halloween-focus mt-1 rounded-full border border-orange-200/20 px-4 py-2 text-xs text-orange-100">{copy.playAgain}</button>
                    </div>
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center">
                      <p className="text-xs text-muted-foreground" aria-live="polite">{reactionMessage || copy.falseStart}</p>
                      {reactionMessage === copy.falseStart ? (
                        <button type="button" onClick={() => startReactionRound(reactionRound)} className="halloween-focus rounded-full border border-violet-200/15 px-4 py-2 text-xs text-violet-100">{copy.playAgain}</button>
                      ) : (
                        <button type="button" onClick={() => startReactionRound(reactionRound + 1)} className="halloween-focus inline-flex items-center gap-2 rounded-full border border-violet-200/15 px-4 py-2 text-xs text-violet-100">{copy.nextRound}<ArrowRight className="h-3 w-3" /></button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </section>

          <section className="halloween-card rounded-[1.75rem] p-5 sm:p-7" aria-labelledby="poll-heading">
            <div className="mb-5">
              <p className="mb-2 text-[10px] font-semibold uppercase tracking-[.2em] text-orange-200/55">02 / CHOOSE</p>
              <h2 id="poll-heading" className="font-serif text-2xl text-foreground">{copy.polls}</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{copy.pollSet[activePoll].question}</p>
            </div>
            <div className="mb-4 grid grid-cols-6 gap-1.5" role="tablist" aria-label={copy.polls}>
              {POLLS.map((poll, index) => (
                <button type="button" key={poll.id} role="tab" aria-selected={activePoll === index} onClick={() => setActivePoll(index)}
                  className={`halloween-focus rounded-lg py-2 text-[10px] font-mono transition-colors ${activePoll === index ? "bg-orange-200/10 text-orange-100 ring-1 ring-orange-200/20" : "bg-white/[.025] text-muted-foreground/55 hover:bg-white/[.06] hover:text-foreground"}`}
                >Q{index + 1}</button>
              ))}
            </div>
            {votesQuery.isLoading ? (
              <div className="space-y-3" aria-label={copy.loading}>{[0, 1, 2, 3].map((item) => <div key={item} className="h-[58px] animate-pulse rounded-xl bg-white/[.045]" />)}</div>
            ) : votesQuery.isError ? (
              <div className="rounded-xl border border-red-300/15 bg-red-300/[.04] p-4">
                <div className="flex items-start gap-2 text-sm text-red-200/80"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{copy.error}</div>
                <button type="button" onClick={() => votesQuery.refetch()} className="halloween-focus mt-3 inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs text-orange-200 hover:bg-orange-200/10"><RefreshCw className="h-3 w-3" />{copy.retry}</button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {copy.pollSet[activePoll].options.map((option, index) => {
                  const optionId = activeQuestion.options[index];
                  const count = voteRows.find((row) => row.optionId === optionId)?.count ?? 0;
                  const percent = totalVotes ? Math.round(count / totalVotes * 100) : 0;
                  return (
                    <button type="button" key={optionId} onClick={() => castVote(optionId)} disabled={submitVote.isPending} aria-pressed={myVote === optionId}
                      className={`halloween-focus relative w-full overflow-hidden rounded-xl border px-4 py-3 text-left transition-colors ${myVote === optionId ? "border-orange-200/30 bg-orange-200/[.06]" : "border-white/[.07] bg-black/10 hover:border-violet-200/20 hover:bg-white/[.025]"}`}
                    >
                      <span className="absolute inset-y-0 left-0 bg-violet-200/[.055]" style={{ width: `${percent}%` }} />
                      <span className="relative flex items-center justify-between gap-3">
                        <span className="text-sm text-foreground/90">{option}</span>
                        <span className="flex items-center gap-2 text-[11px] tabular-nums text-muted-foreground">
                          {myVote === optionId && <Check className="h-3.5 w-3.5 text-orange-200" />}
                          {totalVotes > 0 ? `${percent}%` : "—"}
                        </span>
                      </span>
                      <span className="relative mt-1 block text-[10px] text-muted-foreground/55">{count} {copy.votes}{myVote === optionId ? ` · ${copy.selected}` : ""}</span>
                    </button>
                  );
                })}
                {submitVote.isError && (
                  <div className="flex items-center justify-between gap-2 text-xs text-red-200/80" role="alert">
                    <span className="flex items-center gap-2"><AlertTriangle className="h-3.5 w-3.5 shrink-0" />{copy.voteError}</span>
                    {lastVoteAttempt && <button type="button" onClick={() => castVote(lastVoteAttempt)} className="halloween-focus shrink-0 rounded-md px-2 py-1 text-orange-200 hover:bg-orange-200/10">{copy.retry}</button>}
                  </div>
                )}
                <div className="flex items-center justify-between border-t border-white/[.06] pt-3 text-[10px] text-muted-foreground/50">
                  <span className="inline-flex items-center gap-1.5"><Vote className="h-3 w-3" />{totalVotes} {copy.votes}</span>
                  <span>{myVote ? copy.change : copy.cast}</span>
                </div>
              </div>
            )}
          </section>
        </div>

        <section className="halloween-card mt-5 rounded-[1.75rem] p-5 sm:p-7" aria-labelledby="trivia-heading">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="mb-2 text-[10px] font-semibold uppercase tracking-[.2em] text-violet-200/55">03 / REMEMBER</p>
              <h2 id="trivia-heading" className="font-serif text-2xl">{copy.trivia}</h2>
              <p className="mt-1 text-xs text-muted-foreground">{copy.triviaIntro}</p>
            </div>
            {!triviaFinished && <div className="rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-muted-foreground">{copy.question} {triviaIndex + 1}/5</div>}
          </div>
          {triviaFinished ? (
            <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-orange-200/10 bg-orange-200/[.035] p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-[.18em] text-orange-100/55">{copy.finalScore}</p>
                <p className="mt-1 font-mono text-3xl text-orange-100">{triviaScore}<span className="text-base text-muted-foreground"> / 5</span></p>
                <p className="mt-2 text-sm text-violet-100/75">{copy.triviaResults[resultIndex]}</p>
              </div>
              <button type="button" onClick={restartTrivia} className="halloween-focus inline-flex items-center justify-center gap-2 rounded-xl border border-orange-200/20 px-4 py-2.5 text-xs text-orange-100 hover:bg-orange-200/[.07]"><RefreshCw className="h-3.5 w-3.5" />{copy.playAgain}</button>
            </div>
          ) : (
            <div className="mt-5 rounded-2xl border border-white/[.07] bg-black/15 p-4 sm:p-5">
              <p className="text-sm font-medium leading-6">{copy.triviaSet[triviaIndex].question}</p>
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                {copy.triviaSet[triviaIndex].options.map((option, index) => {
                  const isSelected = triviaChoice === index;
                  const isCorrect = index === copy.triviaSet[triviaIndex].correct;
                  return (
                    <button key={option} type="button" disabled={triviaChoice !== null} onClick={() => answerTrivia(index)}
                      className={`halloween-focus rounded-xl border px-3 py-3 text-left text-xs transition-colors ${triviaChoice === null ? "border-white/[.07] text-muted-foreground hover:border-violet-200/20 hover:bg-violet-200/[.035]" : isCorrect ? "border-orange-200/25 bg-orange-200/[.07] text-orange-100" : isSelected ? "border-red-200/20 bg-red-200/[.04] text-red-100/80" : "border-white/[.04] text-muted-foreground/45"}`}
                    >{option}</button>
                  );
                })}
              </div>
              {triviaChoice !== null && (
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <p className={`text-xs ${triviaChoice === copy.triviaSet[triviaIndex].correct ? "text-orange-100" : "text-muted-foreground"}`} aria-live="polite">{triviaChoice === copy.triviaSet[triviaIndex].correct ? copy.correct : copy.incorrect} · {triviaScore}/5</p>
                  <button type="button" onClick={advanceTrivia} className="halloween-focus inline-flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-orange-100 hover:bg-orange-200/[.06]">{triviaIndex === 4 ? copy.seeResult : copy.nextQuestion}<ArrowRight className="h-3.5 w-3.5" /></button>
                </div>
              )}
            </div>
          )}
        </section>

        <footer className="mt-7 flex items-center justify-between gap-3 px-1 text-[11px] text-muted-foreground/45">
          <span>{copy.footer}</span>
          <Link href="/chat" className="halloween-focus rounded px-2 py-1 text-orange-200/70 transition-colors hover:text-orange-100">{copy.back}</Link>
        </footer>
      </div>
    </main>
  );
}
