import { useState, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, RefreshCw, Trophy, Calendar, Clock, Wifi, AlertCircle, ChevronDown, ChevronUp, BarChart2 } from "lucide-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type MatchStatus = "SCHEDULED" | "TIMED" | "IN_PLAY" | "PAUSED" | "FINISHED" | "SUSPENDED" | "POSTPONED" | "CANCELLED";

interface Team { id: number; name: string; shortName?: string; crest?: string }
interface Score { home: number | null; away: number | null }
interface Goal { minute: number; team: { id: number }; scorer?: { name: string }; assist?: { name: string } }
interface Booking { minute: number; team: { id: number }; player?: { name: string }; card: "YELLOW_CARD" | "RED_CARD" }
interface Match {
  id: number;
  status: MatchStatus;
  stage: string;
  group?: string;
  matchday?: number;
  utcDate: string;
  homeTeam: Team;
  awayTeam: Team;
  score: { fullTime: Score; halfTime: Score };
  venue?: string;
  goals?: Goal[];
  bookings?: Booking[];
  minute?: number;
}

interface StandingRow {
  position: number;
  team: Team;
  playedGames: number;
  won: number;
  draw: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

interface Group { stage: string; group: string; table: StandingRow[] }

function getVoterToken(): string {
  const key = "chatia-voter-token";
  let t = localStorage.getItem(key);
  if (!t) { t = Math.random().toString(36).slice(2) + Date.now(); localStorage.setItem(key, t); }
  return t;
}

const STATUS_LABEL: Record<MatchStatus, string> = {
  SCHEDULED: "Scheduled", TIMED: "Upcoming", IN_PLAY: "LIVE",
  PAUSED: "Half Time", FINISHED: "FT", SUSPENDED: "Suspended",
  POSTPONED: "Postponed", CANCELLED: "Cancelled",
};

function formatDate(utc: string) {
  const d = new Date(utc);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
function formatTime(utc: string) {
  const d = new Date(utc);
  return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}
function stageLabel(stage: string) {
  const map: Record<string, string> = {
    GROUP_STAGE: "Group Stage", ROUND_OF_16: "Round of 16",
    QUARTER_FINALS: "Quarter Finals", SEMI_FINALS: "Semi Finals",
    THIRD_PLACE: "3rd Place", FINAL: "Final",
  };
  return map[stage] ?? stage.replace(/_/g, " ");
}

function TeamCrest({ team, size = 32 }: { team: Team; size?: number }) {
  const [err, setErr] = useState(false);
  if (team.crest && !err) {
    return (
      <img
        src={team.crest}
        alt={team.name}
        width={size}
        height={size}
        onError={() => setErr(true)}
        className="object-contain rounded-sm"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      className="rounded-sm bg-white/8 flex items-center justify-center text-xs font-bold text-muted-foreground"
      style={{ width: size, height: size }}
    >
      {(team.shortName ?? team.name).slice(0, 3).toUpperCase()}
    </div>
  );
}

function MatchCard({ match, onClick }: { match: Match; onClick: () => void }) {
  const isLive = match.status === "IN_PLAY" || match.status === "PAUSED";
  const isFinished = match.status === "FINISHED";
  const hasScore = isLive || isFinished;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="group p-4 rounded-2xl bg-card/60 border border-white/6 hover:border-white/14 hover:bg-card/90 cursor-pointer transition-all duration-200 hover:-translate-y-0.5"
    >
      {/* Status + date row */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {isLive ? (
            <span className="flex items-center gap-1.5 text-xs font-bold text-red-400 bg-red-400/12 px-2 py-0.5 rounded-full border border-red-400/20">
              <span className="w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" />
              LIVE {match.status === "PAUSED" ? "· HT" : ""}
            </span>
          ) : (
            <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${
              isFinished ? "text-muted-foreground/60 bg-white/4 border-white/6" : "text-primary/70 bg-primary/8 border-primary/15"
            }`}>
              {STATUS_LABEL[match.status]}
            </span>
          )}
          <span className="text-[11px] text-muted-foreground/35">{stageLabel(match.stage)}{match.group ? ` · ${match.group}` : ""}</span>
        </div>
        <span className="text-[11px] text-muted-foreground/40">{formatDate(match.utcDate)} · {formatTime(match.utcDate)}</span>
      </div>

      {/* Teams + score */}
      <div className="flex items-center gap-3">
        {/* Home */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <TeamCrest team={match.homeTeam} size={28} />
          <span className={`text-sm font-semibold truncate ${hasScore && match.score.fullTime.home !== null && match.score.fullTime.home > (match.score.fullTime.away ?? -1) ? "text-foreground" : "text-muted-foreground/80"}`}>
            {match.homeTeam.shortName ?? match.homeTeam.name}
          </span>
        </div>

        {/* Score */}
        <div className="flex items-center gap-1.5 flex-shrink-0 min-w-[56px] justify-center">
          {hasScore ? (
            <>
              <span className={`text-lg font-black tabular-nums ${isLive ? "text-white" : "text-foreground/80"}`}>
                {match.score.fullTime.home ?? 0}
              </span>
              <span className="text-muted-foreground/30 text-sm">–</span>
              <span className={`text-lg font-black tabular-nums ${isLive ? "text-white" : "text-foreground/80"}`}>
                {match.score.fullTime.away ?? 0}
              </span>
            </>
          ) : (
            <span className="text-muted-foreground/40 text-sm font-medium">vs</span>
          )}
        </div>

        {/* Away */}
        <div className="flex items-center gap-2 flex-1 min-w-0 justify-end">
          <span className={`text-sm font-semibold truncate text-right ${hasScore && match.score.fullTime.away !== null && match.score.fullTime.away > (match.score.fullTime.home ?? -1) ? "text-foreground" : "text-muted-foreground/80"}`}>
            {match.awayTeam.shortName ?? match.awayTeam.name}
          </span>
          <TeamCrest team={match.awayTeam} size={28} />
        </div>
      </div>

      {/* Scorers */}
      {match.goals && match.goals.length > 0 && (
        <div className="mt-2.5 pt-2.5 border-t border-white/5 text-[11px] text-muted-foreground/40 flex gap-4">
          <span>
            {match.goals.filter(g => g.team.id === match.homeTeam.id).map(g => `${g.scorer?.name ?? "?"} ${g.minute}'`).join(", ")}
          </span>
          <span className="ml-auto text-right">
            {match.goals.filter(g => g.team.id === match.awayTeam.id).map(g => `${g.scorer?.name ?? "?"} ${g.minute}'`).join(", ")}
          </span>
        </div>
      )}
    </motion.div>
  );
}

function MatchDetail({ match, onClose }: { match: Match; onClose: () => void }) {
  const [votes, setVotes] = useState<{ teamId: string; count: number }[]>([]);
  const [myVote, setMyVote] = useState<string | null>(localStorage.getItem(`vote-${match.id}`));
  const [voting, setVoting] = useState(false);

  useEffect(() => {
    fetch(`${BASE}/api/worldcup/votes/${match.id}`)
      .then(r => r.json())
      .then(rows => setVotes(rows.map((r: any) => ({ teamId: r.teamId, count: r.count }))))
      .catch(() => {});
  }, [match.id]);

  const totalVotes = votes.reduce((s, v) => s + v.count, 0);
  const getPct = (teamId: string) => totalVotes === 0 ? 50 : Math.round((votes.find(v => v.teamId === String(teamId))?.count ?? 0) / totalVotes * 100);

  const castVote = async (teamId: string) => {
    if (voting) return;
    setVoting(true);
    try {
      const res = await fetch(`${BASE}/api/worldcup/votes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ matchId: String(match.id), teamId, voterToken: getVoterToken() }),
      });
      const rows = await res.json();
      setVotes(rows.map((r: any) => ({ teamId: r.teamId, count: r.count })));
      setMyVote(teamId);
      localStorage.setItem(`vote-${match.id}`, teamId);
    } catch {}
    setVoting(false);
  };

  const isLive = match.status === "IN_PLAY" || match.status === "PAUSED";
  const isFinished = match.status === "FINISHED";
  const hasScore = isLive || isFinished;

  const yellowHome = match.bookings?.filter(b => b.team.id === match.homeTeam.id && b.card === "YELLOW_CARD").length ?? 0;
  const redHome = match.bookings?.filter(b => b.team.id === match.homeTeam.id && b.card === "RED_CARD").length ?? 0;
  const yellowAway = match.bookings?.filter(b => b.team.id === match.awayTeam.id && b.card === "YELLOW_CARD").length ?? 0;
  const redAway = match.bookings?.filter(b => b.team.id === match.awayTeam.id && b.card === "RED_CARD").length ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 60, scale: 0.97 }}
        animate={{ y: 0, scale: 1 }}
        exit={{ y: 60, scale: 0.97 }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md bg-card border border-white/10 rounded-3xl overflow-hidden shadow-2xl max-h-[85vh] flex flex-col"
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-4 flex-shrink-0 relative" style={{ background: "linear-gradient(135deg, #0d1f3c 0%, #0a0a0f 100%)" }}>
          <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-full bg-white/8 hover:bg-white/14 text-muted-foreground transition-colors">
            <ChevronDown className="h-4 w-4" />
          </button>
          <div className="text-[10px] text-primary/60 font-semibold tracking-widest uppercase mb-3">{stageLabel(match.stage)}</div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-center gap-1.5 flex-1">
              <TeamCrest team={match.homeTeam} size={48} />
              <span className="text-sm font-bold text-foreground text-center leading-tight">{match.homeTeam.shortName ?? match.homeTeam.name}</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              {hasScore ? (
                <div className="text-3xl font-black text-white tabular-nums">
                  {match.score.fullTime.home ?? 0} – {match.score.fullTime.away ?? 0}
                </div>
              ) : (
                <div className="text-sm text-muted-foreground/60 font-medium">vs</div>
              )}
              {isLive ? (
                <span className="text-xs text-red-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" /> LIVE
                </span>
              ) : (
                <span className="text-xs text-muted-foreground/40">{STATUS_LABEL[match.status]}</span>
              )}
            </div>
            <div className="flex flex-col items-center gap-1.5 flex-1">
              <TeamCrest team={match.awayTeam} size={48} />
              <span className="text-sm font-bold text-foreground text-center leading-tight">{match.awayTeam.shortName ?? match.awayTeam.name}</span>
            </div>
          </div>
          <div className="mt-3 text-center text-[11px] text-muted-foreground/40">
            {formatDate(match.utcDate)} · {formatTime(match.utcDate)}
            {match.venue ? ` · ${match.venue}` : ""}
          </div>
          {/* Cards row */}
          {(yellowHome > 0 || redHome > 0 || yellowAway > 0 || redAway > 0) && (
            <div className="flex items-center justify-between mt-2 px-4">
              <div className="flex gap-1">
                {Array.from({ length: yellowHome }).map((_, i) => <span key={i} className="w-3 h-4 rounded-sm bg-yellow-400 inline-block" />)}
                {Array.from({ length: redHome }).map((_, i) => <span key={i} className="w-3 h-4 rounded-sm bg-red-500 inline-block" />)}
              </div>
              <div className="flex gap-1">
                {Array.from({ length: yellowAway }).map((_, i) => <span key={i} className="w-3 h-4 rounded-sm bg-yellow-400 inline-block" />)}
                {Array.from({ length: redAway }).map((_, i) => <span key={i} className="w-3 h-4 rounded-sm bg-red-500 inline-block" />)}
              </div>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {/* Goals */}
          {match.goals && match.goals.length > 0 && (
            <div className="px-5 py-4 border-b border-white/5">
              <p className="text-[10px] font-semibold text-muted-foreground/35 uppercase tracking-widest mb-2">Goals</p>
              <div className="space-y-1.5">
                {match.goals.map((g, i) => {
                  const isHome = g.team.id === match.homeTeam.id;
                  return (
                    <div key={i} className={`flex items-center gap-2 text-sm ${isHome ? "flex-row" : "flex-row-reverse"}`}>
                      <span className="text-[10px] text-muted-foreground/40 w-7 text-center">{g.minute}'</span>
                      <span className="text-base">⚽</span>
                      <span className="text-foreground/80 font-medium">{g.scorer?.name ?? "Own Goal"}</span>
                      {g.assist && <span className="text-muted-foreground/40 text-[11px]">(A: {g.assist.name})</span>}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Bookings */}
          {match.bookings && match.bookings.length > 0 && (
            <div className="px-5 py-4 border-b border-white/5">
              <p className="text-[10px] font-semibold text-muted-foreground/35 uppercase tracking-widest mb-2">Cards</p>
              <div className="space-y-1.5">
                {match.bookings.map((b, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-[10px] text-muted-foreground/40 w-7 text-center">{b.minute}'</span>
                    <span className={`w-3 h-4 rounded-sm ${b.card === "YELLOW_CARD" ? "bg-yellow-400" : "bg-red-500"} flex-shrink-0`} />
                    <span className="text-foreground/80">{b.player?.name ?? "?"}</span>
                    <span className="text-muted-foreground/30 text-[11px] ml-auto">{b.team.id === match.homeTeam.id ? match.homeTeam.shortName : match.awayTeam.shortName}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Prediction/voting */}
          {(match.status === "SCHEDULED" || match.status === "TIMED" || match.status === "IN_PLAY") && (
            <div className="px-5 py-4">
              <p className="text-[10px] font-semibold text-muted-foreground/35 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                <BarChart2 className="h-3 w-3" /> Who will win?
              </p>
              <div className="space-y-2">
                {[match.homeTeam, match.awayTeam].map((team) => {
                  const pct = getPct(String(team.id));
                  const isMyVote = myVote === String(team.id);
                  return (
                    <div key={team.id}>
                      <button
                        onClick={() => castVote(String(team.id))}
                        disabled={voting}
                        className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all duration-150 text-left ${
                          isMyVote
                            ? "border-primary/40 bg-primary/10 text-primary"
                            : "border-white/8 hover:border-white/15 hover:bg-white/4 text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <TeamCrest team={team} size={24} />
                        <span className="text-sm font-medium flex-1">{team.shortName ?? team.name}</span>
                        <span className="text-sm font-bold tabular-nums">{pct}%</span>
                        {isMyVote && <span className="text-xs text-primary">✓ Your pick</span>}
                      </button>
                      <div className="mt-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.6, ease: "easeOut" }}
                          className={`h-full rounded-full ${isMyVote ? "bg-primary" : "bg-white/20"}`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
              {totalVotes > 0 && <p className="text-[10px] text-muted-foreground/30 mt-2 text-center">{totalVotes} vote{totalVotes !== 1 ? "s" : ""}</p>}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

function StandingsTab({ groups }: { groups: Group[] }) {
  const [open, setOpen] = useState<string>(groups[0]?.group ?? "");
  return (
    <div className="space-y-3">
      {groups.map((g) => (
        <div key={g.group} className="rounded-2xl bg-card/60 border border-white/6 overflow-hidden">
          <button
            onClick={() => setOpen(open === g.group ? "" : g.group)}
            className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/4 transition-colors"
          >
            <span className="text-sm font-semibold text-foreground">{g.group}</span>
            {open === g.group ? <ChevronUp className="h-4 w-4 text-muted-foreground/40" /> : <ChevronDown className="h-4 w-4 text-muted-foreground/40" />}
          </button>
          <AnimatePresence>
            {open === g.group && (
              <motion.div
                initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }}
                className="overflow-hidden"
              >
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-t border-white/5 text-muted-foreground/35 uppercase tracking-wide">
                      <th className="px-4 py-2 text-left font-medium w-6">#</th>
                      <th className="px-2 py-2 text-left font-medium">Team</th>
                      <th className="px-2 py-2 text-center font-medium">P</th>
                      <th className="px-2 py-2 text-center font-medium">W</th>
                      <th className="px-2 py-2 text-center font-medium">D</th>
                      <th className="px-2 py-2 text-center font-medium">L</th>
                      <th className="px-2 py-2 text-center font-medium">GD</th>
                      <th className="px-2 py-2 text-center font-medium">Pts</th>
                    </tr>
                  </thead>
                  <tbody>
                    {g.table.map((row) => (
                      <tr key={row.team.id} className="border-t border-white/4 hover:bg-white/3 transition-colors">
                        <td className="px-4 py-2 text-muted-foreground/40 font-mono">{row.position}</td>
                        <td className="px-2 py-2">
                          <div className="flex items-center gap-2">
                            <TeamCrest team={row.team} size={18} />
                            <span className="text-foreground/80 font-medium truncate max-w-[100px]">{row.team.shortName ?? row.team.name}</span>
                          </div>
                        </td>
                        <td className="px-2 py-2 text-center text-muted-foreground/60">{row.playedGames}</td>
                        <td className="px-2 py-2 text-center text-green-400/70">{row.won}</td>
                        <td className="px-2 py-2 text-center text-muted-foreground/60">{row.draw}</td>
                        <td className="px-2 py-2 text-center text-red-400/70">{row.lost}</td>
                        <td className="px-2 py-2 text-center text-muted-foreground/60">{row.goalDifference > 0 ? `+${row.goalDifference}` : row.goalDifference}</td>
                        <td className="px-2 py-2 text-center font-bold text-foreground">{row.points}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}

type Tab = "live" | "upcoming" | "results" | "groups";

export default function WorldCup() {
  const [tab, setTab] = useState<Tab>("live");
  const [matches, setMatches] = useState<Match[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [noApiKey, setNoApiKey] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchMatches = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const res = await fetch(`${BASE}/api/worldcup/matches`);
      if (res.status === 503) { setNoApiKey(true); setLoading(false); setRefreshing(false); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setMatches(data.matches ?? []);
      setLastUpdated(new Date());
      setError(null);
    } catch (e: any) {
      if (!silent) setError(e.message);
    }
    setLoading(false);
    setRefreshing(false);
  }, []);

  const fetchStandings = useCallback(async () => {
    try {
      const res = await fetch(`${BASE}/api/worldcup/standings`);
      if (!res.ok) return;
      const data = await res.json();
      const gs: Group[] = (data.standings ?? []).filter((s: any) => s.type === "TOTAL");
      setGroups(gs);
    } catch {}
  }, []);

  useEffect(() => {
    fetchMatches();
    fetchStandings();
    // Poll every 30s for live updates
    const interval = setInterval(() => fetchMatches(true), 30_000);
    return () => clearInterval(interval);
  }, [fetchMatches, fetchStandings]);

  const liveMatches = matches.filter(m => m.status === "IN_PLAY" || m.status === "PAUSED");
  const upcomingMatches = matches.filter(m => m.status === "SCHEDULED" || m.status === "TIMED");
  const finishedMatches = matches.filter(m => m.status === "FINISHED");

  const tabMatches: Record<Tab, Match[]> = {
    live: liveMatches,
    upcoming: upcomingMatches,
    results: finishedMatches,
    groups: [],
  };

  const TABS: { key: Tab; label: string; count?: number }[] = [
    { key: "live", label: "Live", count: liveMatches.length },
    { key: "upcoming", label: "Upcoming", count: upcomingMatches.length },
    { key: "results", label: "Results", count: finishedMatches.length },
    { key: "groups", label: "Groups" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="relative overflow-hidden flex-shrink-0" style={{ background: "linear-gradient(135deg, #0a0a0f 0%, #0d1f3c 60%, #0a0a0f 100%)" }}>
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-primary/8 rounded-full blur-[80px]" />
          <div className="absolute bottom-0 left-0 w-60 h-60 bg-yellow-400/5 rounded-full blur-[60px]" />
        </div>
        <div className="relative px-4 pt-4 pb-5">
          <div className="flex items-center justify-between mb-4">
            <Link href="/chat">
              <button className="flex items-center gap-1.5 text-sm text-muted-foreground/60 hover:text-foreground transition-colors">
                <ArrowLeft className="h-4 w-4" />
                Back to Chat
              </button>
            </Link>
            <button
              onClick={() => fetchMatches(true)}
              disabled={refreshing}
              className="p-2 rounded-xl bg-white/6 hover:bg-white/10 border border-white/8 text-muted-foreground/60 hover:text-foreground transition-all"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
            </button>
          </div>

          <div className="flex items-center gap-4">
            <img src="/wc-icon.png" alt="World Cup" className="w-14 h-14 object-contain drop-shadow-[0_0_20px_rgba(250,204,21,.4)]" />
            <div>
              <div className="text-[10px] text-primary/60 font-semibold tracking-widest uppercase">FIFA</div>
              <h1 className="text-2xl font-black text-white leading-tight">World Cup <span className="text-yellow-400">2026</span></h1>
              <div className="flex items-center gap-2 mt-0.5">
                {liveMatches.length > 0 && (
                  <span className="flex items-center gap-1 text-[11px] text-red-400 font-semibold">
                    <span className="w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" />
                    {liveMatches.length} live
                  </span>
                )}
                {lastUpdated && (
                  <span className="text-[10px] text-muted-foreground/30">Updated {lastUpdated.toLocaleTimeString()}</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="relative flex border-t border-white/6">
          {TABS.map(({ key, label, count }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex-1 py-2.5 text-xs font-semibold transition-all relative ${tab === key ? "text-primary" : "text-muted-foreground/50 hover:text-muted-foreground"}`}
            >
              {label}
              {count !== undefined && count > 0 && (
                <span className={`ml-1 text-[10px] px-1.5 py-0.5 rounded-full ${tab === key ? "bg-primary/15 text-primary" : "bg-white/6 text-muted-foreground/40"}`}>
                  {count}
                </span>
              )}
              {tab === key && (
                <motion.div layoutId="tab-indicator" className="absolute bottom-0 left-2 right-2 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
        {noApiKey ? (
          <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-yellow-400/10 border border-yellow-400/20 flex items-center justify-center">
              <Trophy className="h-8 w-8 text-yellow-400/60" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground mb-2">Football API Not Configured</h3>
              <p className="text-sm text-muted-foreground/60 max-w-xs leading-relaxed">
                To show live World Cup data, add a free API key from{" "}
                <a href="https://www.football-data.org" target="_blank" rel="noreferrer" className="text-primary hover:underline">
                  football-data.org
                </a>{" "}
                as the{" "}
                <code className="text-xs bg-white/8 px-1.5 py-0.5 rounded font-mono text-yellow-400">FOOTBALL_DATA_API_KEY</code>{" "}
                environment variable.
              </p>
            </div>
          </div>
        ) : loading ? (
          <div className="space-y-3">
            {[1,2,3,4].map(i => <div key={i} className="h-24 rounded-2xl bg-white/4 animate-pulse" />)}
          </div>
        ) : error ? (
          <div className="flex flex-col items-center py-16 gap-3 text-center">
            <AlertCircle className="h-8 w-8 text-destructive/60" />
            <p className="text-sm text-muted-foreground/60">{error}</p>
            <button onClick={() => fetchMatches()} className="text-xs text-primary hover:underline">Retry</button>
          </div>
        ) : tab === "groups" ? (
          groups.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground/40 text-sm">Group standings not available yet</div>
          ) : (
            <StandingsTab groups={groups} />
          )
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {tabMatches[tab].length === 0 ? (
                <div className="flex flex-col items-center py-16 gap-3 text-center">
                  {tab === "live" ? (
                    <>
                      <Wifi className="h-8 w-8 text-muted-foreground/20" />
                      <p className="text-sm text-muted-foreground/40">No matches live right now</p>
                    </>
                  ) : (
                    <>
                      <Calendar className="h-8 w-8 text-muted-foreground/20" />
                      <p className="text-sm text-muted-foreground/40">No {tab} matches</p>
                    </>
                  )}
                </div>
              ) : (
                <div className="space-y-2.5">
                  {tabMatches[tab].map(m => (
                    <MatchCard key={m.id} match={m} onClick={() => setSelectedMatch(m)} />
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        )}
      </div>

      {/* Match detail modal */}
      <AnimatePresence>
        {selectedMatch && (
          <MatchDetail match={selectedMatch} onClose={() => setSelectedMatch(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
