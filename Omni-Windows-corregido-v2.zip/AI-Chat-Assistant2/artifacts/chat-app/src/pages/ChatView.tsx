import { ChatLayout } from "@/components/ChatLayout";
import { ChatInput } from "@/components/ChatInput";
import { MessageBubble, TypingIndicator, WebSearchIndicator } from "@/components/MessageBubble";
import { ChatHeader } from "@/components/ChatHeader";
import {
  useCreateOpenaiConversation,
  useGetOpenaiConversation,
  getGetOpenaiConversationQueryKey,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { sendStreamingMessage } from "@/lib/streaming";
import { toast } from "@/hooks/use-toast";
import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { Sparkles, Ghost, Lightbulb, Moon } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { type OpenaiMessage } from "@workspace/api-client-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/context/LanguageContext";

const SUGGESTIONS_BY_LANG: Record<string, { icon: React.ElementType; label: string; prompt: string }[]> = {
  en: [
    { icon: Moon,      label: "Choose a costume", prompt: "Help me invent a clever Halloween costume using things I already own" },
    { icon: Ghost,     label: "Tell a ghost story", prompt: "Write a short, atmospheric ghost story set in an abandoned observatory" },
    { icon: Sparkles,  label: "Plan a spooky night", prompt: "Plan a cozy Halloween night with a film, a simple snack, and a low-key game" },
    { icon: Lightbulb, label: "Make a mystery", prompt: "Create a Halloween riddle with clues and let me solve it one step at a time" },
  ],
  es: [
    { icon: Moon,      label: "Elegir disfraz", prompt: "Ayúdame a inventar un disfraz ingenioso de Halloween con cosas que ya tengo" },
    { icon: Ghost,     label: "Contar un relato", prompt: "Escribe un relato breve de fantasmas ambientado en un observatorio abandonado" },
    { icon: Sparkles,  label: "Planear la noche", prompt: "Planea una noche acogedora de Halloween con una película, algo sencillo para picar y un juego" },
    { icon: Lightbulb, label: "Crear un misterio", prompt: "Crea un acertijo de Halloween con pistas para que lo resuelva paso a paso" },
  ],
  ar: [
    { icon: Moon,      label: "اختر زياً تنكرياً", prompt: "ساعدني في ابتكار زي هالوين مميز باستخدام أشياء أملكها بالفعل" },
    { icon: Ghost,     label: "اكتب قصة شبح", prompt: "اكتب قصة أشباح قصيرة بأجواء غامضة تدور أحداثها في مرصد مهجور" },
    { icon: Sparkles,  label: "خطط لليلة هالوين", prompt: "خطط لليلة هالوين هادئة مع فيلم ووجبة خفيفة بسيطة ولعبة ممتعة" },
    { icon: Lightbulb, label: "اصنع لغزاً", prompt: "ابتكر لغزاً للهالوين مع تلميحات لأحله خطوة بخطوة" },
  ],
  zh: [
    { icon: Moon,      label: "挑选万圣节装扮", prompt: "用我已有的物品，帮我设计一套巧妙的万圣节装扮" },
    { icon: Ghost,     label: "讲一个鬼故事", prompt: "写一个发生在废弃天文台里的短篇氛围感鬼故事" },
    { icon: Sparkles,  label: "安排惊悚之夜", prompt: "安排一个轻松的万圣夜：一部电影、一份简单小吃和一个小游戏" },
    { icon: Lightbulb, label: "设计一个谜题", prompt: "设计一个带线索的万圣节谜题，让我一步步解开" },
  ],
  ja: [
    { icon: Moon,      label: "仮装を考える", prompt: "手持ちのものを使って、気の利いたハロウィンの仮装を考えてください" },
    { icon: Ghost,     label: "幽霊の物語を書く", prompt: "廃墟となった天文台を舞台にした、雰囲気のある短い幽霊の物語を書いてください" },
    { icon: Sparkles,  label: "夜の計画を立てる", prompt: "映画と簡単なおやつ、気軽なゲームを楽しむハロウィンの夜を計画してください" },
    { icon: Lightbulb, label: "謎を作る", prompt: "手がかりをたどって一緒に解けるハロウィンの謎を作ってください" },
  ],
};

type ChatState = "idle" | "searching" | "streaming";

export default function ChatView() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { t, language } = useLanguage();
  const conversationId = params.id ? parseInt(params.id, 10) : null;
  const isNew = !conversationId;

  const [localMessages, setLocalMessages] = useState<OpenaiMessage[]>([]);
  const [streamingContent, setStreamingContent] = useState("");
  const [chatState, setChatState] = useState<ChatState>("idle");
  const [webSearchEnabled, setWebSearchEnabled] = useState(false);
  const [liveTitle, setLiveTitle] = useState<string | undefined>(undefined);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const createConversation = useCreateOpenaiConversation();
  const { data: conversation, isLoading } = useGetOpenaiConversation(conversationId || 0, {
    query: { enabled: !!conversationId, queryKey: getGetOpenaiConversationQueryKey(conversationId ?? 0) },
  });

  useEffect(() => { setLiveTitle(undefined); }, [conversationId]);

  useEffect(() => {
    if (chatState !== "idle") return; // no pisar el mensaje mientras responde
    if (conversation?.messages) setLocalMessages(conversation.messages);
    else if (isNew) setLocalMessages([]);
  }, [conversation?.messages, isNew, chatState]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, []);

  useEffect(() => { scrollToBottom(); }, [localMessages, streamingContent, chatState, scrollToBottom]);

  const handleSend = async (content: string) => {
    let activeConvId = conversationId;

    const tempUserMsg: OpenaiMessage = {
      id: Date.now(),
      conversationId: activeConvId || 0,
      role: "user",
      content,
      createdAt: new Date().toISOString(),
    };

    setLocalMessages((prev) => [...prev, tempUserMsg]);

    // If web search is enabled, show the searching animation first
    if (webSearchEnabled) {
      setChatState("searching");
      await new Promise((r) => setTimeout(r, 1800 + Math.random() * 700));
    }

    setChatState("streaming");
    setStreamingContent("");

    if (isNew) {
      try {
        const newConv = await createConversation.mutateAsync({
          data: { title: content.slice(0, 40) + (content.length > 40 ? "…" : "") },
        });
        activeConvId = newConv.id;
        setLocation(`/chat/${newConv.id}`);
        await new Promise((r) => setTimeout(r, 80));
      } catch (e) {
        toast({ variant: "destructive", title: "No se pudo crear el chat", description: "Revisa DATABASE_URL en el .env y la ventana negra \"Omni API\". " + (e instanceof Error ? e.message : "") });
        setChatState("idle");
        return;
      }
    }

    if (!activeConvId) return;

    let finalContent = "";
    try {
    await sendStreamingMessage(
      activeConvId,
      content,
      (chunk) => {
        finalContent += chunk;
        setStreamingContent(finalContent);
      },
      () => {
        setChatState("idle");
        setStreamingContent("");
        queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(activeConvId!) });
        queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
      },
      (newTitle) => {
        setLiveTitle(newTitle);
        queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
      }
    );
    } catch (e) {
      toast({ variant: "destructive", title: "No se pudo contactar con el servidor", description: "Comprueba que la ventana negra \"Omni API\" sigue abierta y sin errores. " + (e instanceof Error ? e.message : "") });
      setChatState("idle");
      setStreamingContent("");
    }
  };

  const displayTitle = liveTitle ?? conversation?.title;
  const isEmpty = isNew && localMessages.length === 0;
  const isStreaming = chatState === "streaming";
  const isSearching = chatState === "searching";
  const suggestions = SUGGESTIONS_BY_LANG[language] ?? SUGGESTIONS_BY_LANG["en"];

  return (
    <ChatLayout
      headerSlot={
        !isEmpty ? (
          <ChatHeader
            title={displayTitle}
            conversationId={conversationId}
            onTitleChange={setLiveTitle}
          />
        ) : undefined
      }
    >
      <div className="relative flex-1 overflow-y-auto custom-scrollbar">
        <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden="true">
          <svg className="absolute -right-7 top-2 h-40 w-40 text-violet-200/[.045] sm:h-52 sm:w-52" viewBox="0 0 200 200" fill="none">
            <path d="M0 0h200v200M0 0l200 200M100 0v200M0 100h200M25 0c0 42 33 75 75 75M0 25c42 0 75 33 75 75M175 0c0 42-33 75-75 75M200 25c-42 0-75 33-75 75" stroke="currentColor" />
          </svg>
          <svg className="absolute left-[7%] top-[20%] h-8 w-12 text-orange-100/[.07] sm:h-10 sm:w-16" viewBox="0 0 80 48" fill="currentColor">
            <path d="m3 16-2-12 17 9c5-6 12-9 22-9s17 3 22 9l17-9-2 12 2 20-19-10-20 16-20-16L1 36l2-20Z" />
          </svg>
          <svg className="halloween-chat-ghost absolute right-[5%] top-[43%] h-12 w-12 text-violet-100/[.09] sm:h-16 sm:w-16" viewBox="0 0 48 48" fill="none">
            <path d="M9 41V21a15 15 0 0 1 30 0v20l-7-4-8 4-8-4-7 4Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
            <circle cx="19" cy="22" r="1.5" fill="currentColor" /><circle cx="29" cy="22" r="1.5" fill="currentColor" />
          </svg>
          <svg className="absolute bottom-[12%] right-[10%] h-14 w-14 text-orange-100/[.06] sm:h-20 sm:w-20" viewBox="0 0 100 100" fill="none">
            <path d="M48 20c-1-7 4-11 12-11-1 7-5 10-12 11Z" fill="currentColor" />
            <path d="M50 24c-9-7-19-5-26 1-15 13-13 43 1 51 7 4 14 3 21 0 7 3 14 4 21 0 14-8 16-38 1-51-7-6-17-8-26-1Z" stroke="currentColor" strokeWidth="2" />
            <path d="m34 43 7 5-7 5m32-10-7 5 7 5m-16-5v10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <div className="absolute -bottom-10 left-[15%] h-36 w-2/3 rounded-full bg-violet-400/[.025] blur-3xl" />
        </div>
        <div className="relative z-10 max-w-2xl mx-auto w-full px-4 md:px-6 pb-44 pt-8">
          <AnimatePresence mode="wait">
            {isEmpty ? (
              <motion.div
                key="welcome"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col items-center justify-center min-h-[60vh] text-center"
              >
                <div className="relative mb-7">
                  <div className="absolute inset-0 bg-primary/15 blur-3xl rounded-full scale-[2]" />
                  <div className="relative w-16 h-16 rounded-2xl overflow-hidden border border-white/15 shadow-[0_0_32px_rgba(79,142,247,.45)]">
                    <img src="/ai-icon.png" alt="Omni" className="w-full h-full object-cover" />
                  </div>
                </div>
                <h1 className="text-2xl md:text-3xl font-bold mb-2.5 tracking-tight">
                  {t.howCanIHelp}
                </h1>
                <p className="text-[14px] text-muted-foreground max-w-sm leading-relaxed mb-9">
                  {t.askMeAnything}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full max-w-xl">
                  {suggestions.map(({ icon: Icon, label, prompt }, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.08 + i * 0.06 }}
                      onClick={() => handleSend(prompt)}
                      className="group flex items-center gap-3 p-3.5 rounded-xl bg-card/80 border border-white/7 hover:border-primary/25 hover:bg-primary/5 text-left transition-all duration-150 shadow-sm"
                    >
                      <div className="w-8 h-8 rounded-lg bg-white/5 group-hover:bg-primary/12 flex items-center justify-center flex-shrink-0 transition-colors">
                        <Icon className="h-4 w-4 text-primary/70 group-hover:text-primary transition-colors" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[13px] font-medium text-foreground/80 group-hover:text-foreground transition-colors">{label}</p>
                        <p className="text-[11px] text-muted-foreground/45 truncate">{prompt.slice(0, 52)}…</p>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div key="messages" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-7">
                {localMessages.map((msg, i) => (
                  <MessageBubble key={msg.id || i} message={msg} />
                ))}

                <AnimatePresence>
                  {isSearching && <WebSearchIndicator key="searching" text={t.searching} />}
                  {isStreaming && (
                    streamingContent ? (
                      <MessageBubble
                        key="streaming"
                        message={{ role: "assistant", content: streamingContent, createdAt: new Date().toISOString() }}
                        isStreaming
                      />
                    ) : (
                      <TypingIndicator key="typing" />
                    )
                  )}
                </AnimatePresence>

                <div ref={messagesEndRef} className="h-1" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Floating input */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none z-30">
        <div className="pointer-events-auto bg-gradient-to-t from-background via-background/97 to-transparent pt-10 pb-5 px-4 md:px-6">
          <ChatInput
            onSend={handleSend}
            disabled={isLoading}
            isStreaming={isStreaming || isSearching}
            webSearchEnabled={webSearchEnabled}
            onToggleWebSearch={() => setWebSearchEnabled((v) => !v)}
          />
        </div>
      </div>
    </ChatLayout>
  );
}
