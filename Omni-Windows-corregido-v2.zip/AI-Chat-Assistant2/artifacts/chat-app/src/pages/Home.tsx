import { Link } from "wouter";
import { ArrowRight, Download, Smartphone, Zap, Shield, Brain, Code2, MessageSquare, Sparkles, CheckCircle2, Monitor } from "lucide-react";
import { motion, AnimatePresence, type Variants } from "framer-motion";
import { useState } from "react";
import { usePWAInstall } from "@/hooks/usePWAInstall";

const FEATURES = [
  { icon: Zap,           title: "Lightning Fast",      desc: "Real-time streaming responses. Every token appears instantly — no waiting, no spinning.",           color: "from-yellow-500/20 to-orange-500/10",  iconColor: "text-yellow-400" },
  { icon: Shield,        title: "Private & Secure",     desc: "Your conversations stay yours. Enterprise-grade auth via Clerk keeps everything locked tight.",     color: "from-green-500/20 to-emerald-500/10",  iconColor: "text-green-400" },
  { icon: Brain,         title: "GPT-4o Powered",       desc: "State-of-the-art reasoning, coding, writing, and analysis at your fingertips.",                    color: "from-primary/20 to-purple-500/10",     iconColor: "text-primary" },
  { icon: Code2,         title: "Code Aware",           desc: "Full syntax highlighting for 40+ languages. Ask it to write, debug, or explain any code.",         color: "from-purple-500/20 to-pink-500/10",    iconColor: "text-purple-400" },
  { icon: MessageSquare, title: "Conversation History", desc: "All your chats saved and searchable. Favorites, search, and full history in one sidebar.",         color: "from-blue-500/20 to-cyan-500/10",      iconColor: "text-blue-400" },
  { icon: Sparkles,      title: "Web Search Mode",      desc: "Simulate web search to get more grounded, up-to-date answers in any conversation.",                color: "from-pink-500/20 to-rose-500/10",      iconColor: "text-pink-400" },
];

const INSTALL_GUIDES = [
  {
    platform: "Windows / Mac",
    icon: "🖥️",
    steps: [
      "Open Omni in Chrome or Edge",
      "Click the install icon in the address bar",
      "Click Install in the dialog",
    ],
  },
  {
    platform: "Android",
    icon: "🤖",
    steps: [
      "Open Omni in Chrome",
      "Tap the menu (⋮) in the top right",
      "Tap Add to Home Screen",
    ],
  },
  {
    platform: "iPhone / iPad",
    icon: "🍎",
    steps: [
      "Open Omni in Safari",
      "Tap the Share button (↑)",
      "Tap Add to Home Screen",
    ],
  },
];

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.4, ease: "easeOut" },
  }),
};

function InstallToast({ platform, onDismiss }: { platform: string; onDismiss: () => void }) {
  const isIOS = platform === "ios";
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[min(90vw,420px)] bg-card border border-white/12 rounded-2xl shadow-2xl p-4"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl overflow-hidden border border-white/10 flex-shrink-0">
          <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground mb-1">
            Install Omni on {isIOS ? "iPhone / iPad" : "your device"}
          </p>
          {isIOS ? (
            <p className="text-xs text-muted-foreground leading-relaxed">
              Tap <span className="text-primary font-medium">Share ↑</span> in Safari, then{" "}
              <span className="text-primary font-medium">Add to Home Screen</span>.
            </p>
          ) : (
            <p className="text-xs text-muted-foreground leading-relaxed">
              Look for the install icon in your browser address bar, or use{" "}
              <span className="text-primary font-medium">Browser Menu → Install App</span>.
            </p>
          )}
        </div>
        <button
          onClick={onDismiss}
          className="text-muted-foreground/40 hover:text-muted-foreground text-xl leading-none flex-shrink-0 -mt-0.5"
        >
          ×
        </button>
      </div>
    </motion.div>
  );
}

export default function Home() {
  const { install, isInstallable, isInstalled, platform } = usePWAInstall();
  const [showToast, setShowToast] = useState(false);
  const [installing, setInstalling] = useState(false);

  const handleInstall = async () => {
    if (isInstallable) {
      setInstalling(true);
      await install();
      setInstalling(false);
    } else {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 8000);
    }
  };

  const installBtnClass = (active: boolean) =>
    [
      "flex items-center gap-2.5 h-11 px-6 text-sm font-medium rounded-xl border transition-all duration-150",
      isInstalled
        ? "border-green-500/30 bg-green-500/8 text-green-400 cursor-default"
        : active
        ? "border-primary/30 bg-primary/8 text-primary hover:bg-primary/14 hover:border-primary/45"
        : "border-white/8 text-muted-foreground hover:text-foreground hover:border-white/15 hover:bg-white/4",
    ].join(" ");

  return (
    <div className="min-h-screen bg-background flex flex-col relative overflow-hidden">
      {/* Background blobs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-32 w-[600px] h-[600px] bg-primary/8 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 -right-48 w-[500px] h-[500px] bg-purple-600/6 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-1/3 w-[400px] h-[300px] bg-blue-600/5 rounded-full blur-[100px]" />
        <svg className="absolute right-[6%] top-[15%] hidden h-52 w-52 text-orange-200/[.075] lg:block" viewBox="0 0 200 200" fill="none" aria-hidden="true">
          <circle cx="100" cy="100" r="82" stroke="currentColor" />
          <path d="M46 129 100 73l54 56v31H46v-31Z" stroke="currentColor" strokeWidth="2" />
          <path d="M84 160v-39h32v39M62 101V77h18v5" stroke="currentColor" strokeWidth="2" />
          <path d="m136 58 4-10 4 10 10 4-10 4-4 10-4-10-10-4 10-4Z" fill="currentColor" />
        </svg>
        <div className="absolute right-[12%] top-[23%] h-16 w-16 rounded-full border border-violet-200/[.08]" />
        <svg className="absolute -left-7 top-20 h-40 w-40 text-violet-200/[.075] sm:h-56 sm:w-56" viewBox="0 0 200 200" fill="none" aria-hidden="true">
          <path d="M0 0h200v200M0 0l200 200M100 0v200M0 100h200M25 0c0 42 33 75 75 75M0 25c42 0 75 33 75 75M175 0c0 42-33 75-75 75M200 25c-42 0-75 33-75 75" stroke="currentColor" />
        </svg>
        <svg className="absolute right-[13%] top-[46%] h-9 w-14 text-orange-100/[.09] sm:h-12 sm:w-20" viewBox="0 0 80 48" fill="currentColor" aria-hidden="true">
          <path d="m3 16-2-12 17 9c5-6 12-9 22-9s17 3 22 9l17-9-2 12 2 20-19-10-20 16-20-16L1 36l2-20Z" />
        </svg>
        <svg className="absolute bottom-[12%] left-[6%] h-16 w-16 text-violet-100/[.07] sm:h-24 sm:w-24" viewBox="0 0 64 64" fill="currentColor" aria-hidden="true">
          <path d="M40 7a24 24 0 1 0 17 41A25 25 0 0 1 40 7Z" />
          <path d="m19 12 2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5Z" />
        </svg>
        <svg className="absolute bottom-[15%] right-[9%] h-20 w-20 text-orange-100/[.07] sm:h-28 sm:w-28" viewBox="0 0 100 100" fill="none" aria-hidden="true">
          <path d="M48 20c-1-7 4-11 12-11-1 7-5 10-12 11Z" fill="currentColor" />
          <path d="M50 24c-9-7-19-5-26 1-15 13-13 43 1 51 7 4 14 3 21 0 7 3 14 4 21 0 14-8 16-38 1-51-7-6-17-8-26-1Z" stroke="currentColor" strokeWidth="2" />
          <path d="m34 43 7 5-7 5m32-10-7 5 7 5m-16-5v10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="absolute -bottom-12 left-[18%] h-48 w-2/3 rounded-full bg-violet-400/[.045] blur-3xl" />
        <div className="absolute bottom-0 right-0 h-40 w-2/3 rounded-full bg-orange-300/[.035] blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.4) 1px,transparent 1px)",
            backgroundSize: "64px 64px",
          }}
        />
      </div>

      {/* Nav */}
      <header className="relative z-10 px-6 md:px-10 py-5 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl overflow-hidden border border-white/15 shadow-[0_0_20px_rgba(79,142,247,.4)]">
            <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
          </div>
          <span className="font-bold text-lg tracking-tight">Omni</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/sign-in">
            <button className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-white/5">
              Sign In
            </button>
          </Link>
          <Link href="/sign-up">
            <button className="px-4 py-2 text-sm font-medium bg-primary hover:bg-primary/90 text-white rounded-xl shadow-[0_0_16px_rgba(79,142,247,.4)] border border-primary/50 transition-all duration-150">
              Get Started
            </button>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 text-center relative z-10 pt-16 pb-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-4xl mx-auto"
        >
          {/* App icon */}
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="mx-auto mb-7 relative w-24 h-24"
          >
            <div className="absolute inset-0 bg-primary/20 blur-2xl rounded-full scale-150" />
            <div className="relative w-24 h-24 rounded-3xl overflow-hidden border border-white/15 shadow-[0_0_40px_rgba(79,142,247,.5)]">
              <img src="/chat-ia-logo.png" alt="Omni" className="w-full h-full object-cover" />
            </div>
          </motion.div>

          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-sm text-primary mb-8 shadow-[0_0_16px_rgba(79,142,247,.15)]">
            <Sparkles className="h-3.5 w-3.5" />
            Powered by GPT-4o · Built for makers
          </div>

          {/* Headline */}
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.08] mb-6">
            Intelligence meets
            <br />
            <span className="gradient-text">precision design.</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-10">
            A professional AI chat experience — dark, electric, and built for speed. Streaming
            responses, conversation history, code highlighting, and more.
          </p>

          {/* Primary CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
            <Link href="/sign-up">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2.5 h-14 px-8 text-base font-semibold bg-primary hover:bg-primary/90 text-white rounded-2xl shadow-[0_0_30px_rgba(79,142,247,.5)] border border-primary/50 transition-all duration-150 group"
              >
                Start Chatting — Free
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </Link>
            <Link href="/sign-in">
              <button className="flex items-center gap-2 h-14 px-8 text-base text-muted-foreground hover:text-foreground rounded-2xl border border-white/8 hover:border-white/14 hover:bg-white/4 transition-all duration-150">
                Sign In
              </button>
            </Link>
          </div>

          {/* PWA Install buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-3">
            <motion.button
              whileHover={{ scale: isInstalled ? 1 : 1.02 }}
              whileTap={{ scale: isInstalled ? 1 : 0.97 }}
              onClick={handleInstall}
              disabled={isInstalled || installing}
              className={installBtnClass(isInstallable)}
            >
              {isInstalled ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <Monitor className="h-4 w-4" />
              )}
              {isInstalled ? "Installed ✓" : installing ? "Installing…" : "Download for PC"}
              {isInstallable && !isInstalled && (
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              )}
            </motion.button>

            <motion.button
              whileHover={{ scale: isInstalled ? 1 : 1.02 }}
              whileTap={{ scale: isInstalled ? 1 : 0.97 }}
              onClick={handleInstall}
              disabled={isInstalled || installing}
              className={installBtnClass(isInstallable)}
            >
              {isInstalled ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <Smartphone className="h-4 w-4" />
              )}
              {isInstalled ? "Installed ✓" : installing ? "Installing…" : "Download for Mobile"}
              {isInstallable && !isInstalled && (
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              )}
            </motion.button>
          </div>

          {/* Install hint */}
          {isInstallable && !isInstalled && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-primary/60 mb-2"
            >
              ✓ Your browser supports installation — click a button above to install Omni as an app
            </motion.p>
          )}
          {!isInstallable && !isInstalled && (
            <p className="text-xs text-muted-foreground/35 mb-2">
              Works on Chrome, Edge, Safari · No app store required
            </p>
          )}
          {isInstalled && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-green-400/70 mb-2"
            >
              ✓ Omni is installed on this device
            </motion.p>
          )}
        </motion.div>

        {/* Feature cards */}
        <div className="mt-24 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto w-full">
          {FEATURES.map(({ icon: Icon, title, desc, color, iconColor }, i) => (
            <motion.div
              key={title}
              custom={i}
              variants={fadeUp}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "-40px" }}
              className="group p-5 rounded-2xl bg-card/60 border border-white/6 hover:border-white/12 backdrop-blur-sm text-left transition-all duration-200 hover:shadow-[0_4px_24px_rgba(0,0,0,.4)] hover:-translate-y-0.5"
            >
              <div
                className={`w-11 h-11 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 border border-white/6`}
              >
                <Icon className={`h-5 w-5 ${iconColor}`} />
              </div>
              <h3 className="text-sm font-semibold text-foreground mb-1.5">{title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Platform install guide */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4 }}
          className="mt-16 max-w-3xl mx-auto w-full"
        >
          <h2 className="text-lg font-bold mb-6 text-foreground/80">Install on any device</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {INSTALL_GUIDES.map(({ platform, steps, icon }) => (
              <div key={platform} className="p-4 rounded-2xl bg-card/50 border border-white/6 text-left">
                <div className="text-2xl mb-2">{icon}</div>
                <p className="text-sm font-semibold text-foreground mb-2">{platform}</p>
                <ol className="space-y-1.5">
                  {steps.map((step, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-2">
                      <span className="text-primary/50 font-mono flex-shrink-0">{i + 1}.</span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </motion.div>
      </main>

      <footer className="relative z-10 border-t border-white/5 px-8 py-5 text-center">
        <p className="text-xs text-muted-foreground/40">
          © {new Date().getFullYear()} Omni · Built with GPT-4o, React, and love.
        </p>
      </footer>

      {/* Install instructions toast */}
      <AnimatePresence>
        {showToast && (
          <InstallToast platform={platform} onDismiss={() => setShowToast(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
