import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type Language = "en" | "es" | "ar" | "zh" | "ja";

export interface LanguageOption {
  code: Language;
  label: string;
  flag: string;
  dir?: "rtl" | "ltr";
}

export const LANGUAGES: LanguageOption[] = [
  { code: "en", label: "English",  flag: "🇺🇸" },
  { code: "es", label: "Español",  flag: "🇪🇸" },
  { code: "ar", label: "العربية",  flag: "🇸🇦", dir: "rtl" },
  { code: "zh", label: "中文",     flag: "🇨🇳" },
  { code: "ja", label: "日本語",   flag: "🇯🇵" },
];

export const UI_STRINGS: Record<Language, {
  newChat: string;
  search: string;
  settings: string;
  profile: string;
  language: string;
  signOut: string;
  placeholder: string;
  thinking: string;
  searching: string;
  favorites: string;
  recent: string;
  noChats: string;
  copy: string;
  copied: string;
  regenerate: string;
  share: string;
  disclaimer: string;
  howCanIHelp: string;
  askMeAnything: string;
}> = {
  en: {
    newChat: "New Chat",
    search: "Search conversations…",
    settings: "Settings",
    profile: "Profile",
    language: "Language",
    signOut: "Sign out",
    placeholder: "Message Omni…",
    thinking: "Omni is thinking…",
    searching: "Searching the web…",
    favorites: "Favorites",
    recent: "Recent",
    noChats: "No chats yet",
    copy: "Copy",
    copied: "Copied",
    regenerate: "Regenerate",
    share: "Share",
    disclaimer: "Omni can make mistakes. Verify important information independently.",
    howCanIHelp: "How can I help you today?",
    askMeAnything: "Ask me anything — coding, writing, research, or just a quick question.",
  },
  es: {
    newChat: "Nuevo Chat",
    search: "Buscar conversaciones…",
    settings: "Configuración",
    profile: "Perfil",
    language: "Idioma",
    signOut: "Cerrar sesión",
    placeholder: "Mensaje a Omni…",
    thinking: "Omni está pensando…",
    searching: "Buscando en la web…",
    favorites: "Favoritos",
    recent: "Recientes",
    noChats: "Sin chats aún",
    copy: "Copiar",
    copied: "Copiado",
    regenerate: "Reintentar",
    share: "Compartir",
    disclaimer: "Omni puede cometer errores. Verifica la información importante.",
    howCanIHelp: "¿En qué puedo ayudarte hoy?",
    askMeAnything: "Pregúntame cualquier cosa — código, escritura, investigación o una consulta rápida.",
  },
  ar: {
    newChat: "محادثة جديدة",
    search: "البحث في المحادثات…",
    settings: "الإعدادات",
    profile: "الملف الشخصي",
    language: "اللغة",
    signOut: "تسجيل الخروج",
    placeholder: "أرسل رسالة إلى Omni…",
    thinking: "Omni يفكر…",
    searching: "البحث في الويب…",
    favorites: "المفضلة",
    recent: "الأخيرة",
    noChats: "لا توجد محادثات بعد",
    copy: "نسخ",
    copied: "تم النسخ",
    regenerate: "إعادة المحاولة",
    share: "مشاركة",
    disclaimer: "قد يرتكب Omni أخطاء. تحقق من المعلومات المهمة بشكل مستقل.",
    howCanIHelp: "كيف يمكنني مساعدتك اليوم؟",
    askMeAnything: "اسألني عن أي شيء — برمجة، كتابة، بحث، أو مجرد سؤال سريع.",
  },
  zh: {
    newChat: "新对话",
    search: "搜索对话…",
    settings: "设置",
    profile: "个人资料",
    language: "语言",
    signOut: "退出登录",
    placeholder: "发送消息给 Omni…",
    thinking: "Omni 正在思考…",
    searching: "正在搜索网络…",
    favorites: "收藏",
    recent: "最近",
    noChats: "暂无对话",
    copy: "复制",
    copied: "已复制",
    regenerate: "重新生成",
    share: "分享",
    disclaimer: "Omni 可能会出错，请独立验证重要信息。",
    howCanIHelp: "今天我能为您做什么？",
    askMeAnything: "随时向我提问 — 编程、写作、研究或任何问题。",
  },
  ja: {
    newChat: "新しいチャット",
    search: "会話を検索…",
    settings: "設定",
    profile: "プロフィール",
    language: "言語",
    signOut: "サインアウト",
    placeholder: "Omni にメッセージを送信…",
    thinking: "Omni が考えています…",
    searching: "ウェブを検索しています…",
    favorites: "お気に入り",
    recent: "最近",
    noChats: "チャットはまだありません",
    copy: "コピー",
    copied: "コピーしました",
    regenerate: "再生成",
    share: "共有",
    disclaimer: "Omni は誤りを犯すことがあります。重要な情報は個別に確認してください。",
    howCanIHelp: "今日はどのようにお手伝いできますか？",
    askMeAnything: "何でも聞いてください — コーディング、ライティング、調査、または簡単な質問。",
  },
};

interface LanguageContextValue {
  language: Language;
  setLanguage: (l: Language) => void;
  t: typeof UI_STRINGS["en"];
}

const LanguageContext = createContext<LanguageContextValue>({
  language: "en",
  setLanguage: () => {},
  t: UI_STRINGS["en"],
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguagState] = useState<Language>(() => {
    return (localStorage.getItem("chatai-language") as Language) || "en";
  });

  const setLanguage = (l: Language) => {
    localStorage.setItem("chatai-language", l);
    setLanguagState(l);
    // Update document direction for RTL languages
    document.documentElement.dir = LANGUAGES.find(x => x.code === l)?.dir ?? "ltr";
  };

  useEffect(() => {
    document.documentElement.dir = LANGUAGES.find(x => x.code === language)?.dir ?? "ltr";
  }, []);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t: UI_STRINGS[language] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
