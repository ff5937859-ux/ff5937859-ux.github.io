import { useEffect, useRef, useState } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from 'wouter';
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { LanguageProvider } from "@/context/LanguageContext";
import { SplashScreen } from "@/components/SplashScreen";

import Home from "@/pages/Home";
import ChatView from "@/pages/ChatView";
import Settings from "@/pages/Settings";
import Halloween from "@/pages/Halloween";

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/chat-ia-logo.png`,
  },
  variables: {
    colorPrimary: "hsl(217 91% 64%)",
    colorForeground: "hsl(240 20% 93%)",
    colorMutedForeground: "hsl(240 13% 64%)",
    colorDanger: "hsl(0 84.2% 60.2%)",
    colorBackground: "hsl(240 11% 11%)",
    colorInput: "hsl(240 10% 15%)",
    colorInputForeground: "hsl(240 20% 93%)",
    colorNeutral: "hsl(240 10% 15%)",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#18181E] rounded-2xl w-[440px] max-w-full overflow-hidden border border-white/10 shadow-[0_0_40px_rgba(59,130,246,0.15)]",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-bold",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-medium",
    formFieldLabel: "text-foreground font-medium",
    footerActionLink: "text-primary hover:text-primary/80",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary hover:text-primary/80",
    formFieldSuccessText: "text-primary",
    alertText: "text-foreground",
    logoBox: "",
    logoImage: "",
    socialButtonsBlockButton: "border-border hover:bg-white/5",
    formButtonPrimary: "bg-primary hover:bg-primary/90 text-white font-medium",
    formFieldInput: "bg-input border-border text-foreground focus:ring-primary focus:border-primary",
    footerAction: "",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive/20 text-destructive",
    otpCodeFieldInput: "border-border text-foreground focus:ring-primary focus:border-primary",
    formFieldRow: "",
    main: "",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none" />
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden="true">
        <svg className="absolute -left-8 -top-8 h-52 w-52 text-violet-200/[.09] sm:h-64 sm:w-64" viewBox="0 0 200 200" fill="none">
          <path d="M0 0h200v200M0 0l200 200M100 0v200M0 100h200M25 0c0 42 33 75 75 75M0 25c42 0 75 33 75 75M175 0c0 42-33 75-75 75M200 25c-42 0-75 33-75 75" stroke="currentColor" />
        </svg>
        <svg className="absolute right-[9%] top-[14%] h-10 w-14 text-orange-100/[.12] sm:h-14 sm:w-20" viewBox="0 0 80 48" fill="currentColor">
          <path d="m3 16-2-12 17 9c5-6 12-9 22-9s17 3 22 9l17-9-2 12 2 20-19-10-20 16-20-16L1 36l2-20Z" />
        </svg>
        <svg className="absolute bottom-[12%] right-[7%] h-32 w-32 text-orange-200/[.075] sm:h-44 sm:w-44" viewBox="0 0 100 100" fill="none">
          <path d="M48 20c-1-7 4-11 12-11-1 7-5 10-12 11Z" fill="currentColor" />
          <path d="M50 24c-9-7-19-5-26 1-15 13-13 43 1 51 7 4 14 3 21 0 7 3 14 4 21 0 14-8 16-38 1-51-7-6-17-8-26-1Z" stroke="currentColor" strokeWidth="2" />
          <path d="m34 43 7 5-7 5m32-10-7 5 7 5m-16-5v10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="absolute -bottom-16 left-1/4 h-48 w-2/3 rounded-full bg-violet-400/[.045] blur-3xl" />
        <div className="absolute -bottom-20 right-0 h-44 w-2/3 rounded-full bg-orange-300/[.035] blur-3xl" />
      </div>
      <div className="relative z-10">
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
      </div>
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none" />
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden="true">
        <svg className="absolute -left-8 -top-8 h-52 w-52 text-violet-200/[.09] sm:h-64 sm:w-64" viewBox="0 0 200 200" fill="none">
          <path d="M0 0h200v200M0 0l200 200M100 0v200M0 100h200M25 0c0 42 33 75 75 75M0 25c42 0 75 33 75 75M175 0c0 42-33 75-75 75M200 25c-42 0-75 33-75 75" stroke="currentColor" />
        </svg>
        <svg className="absolute right-[9%] top-[14%] h-10 w-14 text-orange-100/[.12] sm:h-14 sm:w-20" viewBox="0 0 80 48" fill="currentColor">
          <path d="m3 16-2-12 17 9c5-6 12-9 22-9s17 3 22 9l17-9-2 12 2 20-19-10-20 16-20-16L1 36l2-20Z" />
        </svg>
        <svg className="absolute bottom-[12%] right-[7%] h-32 w-32 text-orange-200/[.075] sm:h-44 sm:w-44" viewBox="0 0 100 100" fill="none">
          <path d="M48 20c-1-7 4-11 12-11-1 7-5 10-12 11Z" fill="currentColor" />
          <path d="M50 24c-9-7-19-5-26 1-15 13-13 43 1 51 7 4 14 3 21 0 7 3 14 4 21 0 14-8 16-38 1-51-7-6-17-8-26-1Z" stroke="currentColor" strokeWidth="2" />
          <path d="m34 43 7 5-7 5m32-10-7 5 7 5m-16-5v10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="absolute -bottom-16 left-1/4 h-48 w-2/3 rounded-full bg-violet-400/[.045] blur-3xl" />
        <div className="absolute -bottom-20 right-0 h-44 w-2/3 rounded-full bg-orange-300/[.035] blur-3xl" />
      </div>
      <div className="relative z-10">
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      </div>
    </div>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/chat" />
      </Show>
      <Show when="signed-out">
        <Home />
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <>
      <Show when="signed-in">
        <Component />
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

const ChatRoute = () => <ProtectedRoute component={ChatView} />;
const SettingsRoute = () => <ProtectedRoute component={Settings} />;
const HalloweenRoute = () => <ProtectedRoute component={Halloween} />;

function ClerkQueryClientCacheInvalidator({ queryClient }: { queryClient: QueryClient }) {
  const { addListener } = useClerk();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

const queryClient = new QueryClient();

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to access your Omni account",
          },
        },
        signUp: {
          start: {
            title: "Create your account",
            subtitle: "Join Omni today",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator queryClient={queryClient} />
        <TooltipProvider>
          <Switch>
            <Route path="/" component={HomeRedirect} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/chat/:id?" component={ChatRoute} />
            <Route path="/settings" component={SettingsRoute} />
            <Route path="/halloween" component={HalloweenRoute} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function AppWithSplash() {
  const [splashDone, setSplashDone] = useState(() => {
    // Only show splash once per browser session
    const shown = sessionStorage.getItem("chatia-splash-shown");
    if (shown) return true;
    sessionStorage.setItem("chatia-splash-shown", "1");
    return false;
  });

  return (
    <>
      {!splashDone && <SplashScreen onDone={() => setSplashDone(true)} />}
      <WouterRouter base={basePath}>
        <ClerkProviderWithRoutes />
      </WouterRouter>
    </>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AppWithSplash />
    </LanguageProvider>
  );
}

export default App;
