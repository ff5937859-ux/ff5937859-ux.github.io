import { createRoot } from "react-dom/client";
import "./index.css";

const root = document.getElementById("root")!;

function showError(err: unknown) {
  const msg = err instanceof Error ? err.message : String(err);
  const hint = /clerk|publishable/i.test(msg)
    ? "Falta o es incorrecta la clave de Clerk. Abre el archivo .env, pega tus claves reales (pk_test_... y sk_test_...) de clerk.com y vuelve a ejecutar Start.bat."
    : "Revisa la ventana negra «Omni Web» y el archivo .env.";
  root.innerHTML =
    '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0A0A0F;color:#fff;font-family:system-ui,sans-serif;padding:24px">' +
    '<div style="max-width:520px;border:1px solid #8B5CF6;border-radius:16px;padding:24px;background:#18181E">' +
    '<h1 style="margin:0 0 8px;font-size:20px">Omni no puede arrancar</h1>' +
    '<p style="margin:0 0 12px;color:#c4b5fd">' + hint + "</p>" +
    '<pre style="white-space:pre-wrap;font-size:12px;color:#fca5a5;margin:0">' +
    msg.replace(/[<&]/g, (c) => (c === "<" ? "&lt;" : "&amp;")) +
    "</pre></div></div>";
}

import("./App")
  .then(({ default: App }) => createRoot(root).render(<App />))
  .catch(showError);
