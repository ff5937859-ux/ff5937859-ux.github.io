import { Router } from "express";
import { db, votes } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";

const router = Router();
const FOOTBALL_API_BASE = "https://api.football-data.org/v4";
const API_KEY = process.env.FOOTBALL_DATA_API_KEY;

async function footballFetch(path: string) {
  if (!API_KEY) {
    throw new Error("FOOTBALL_DATA_API_KEY is not set");
  }
  const res = await fetch(`${FOOTBALL_API_BASE}${path}`, {
    headers: { "X-Auth-Token": API_KEY },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Football API error ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}

// Cache: { data, fetchedAt }
const cache = new Map<string, { data: unknown; fetchedAt: number }>();
function getCached(key: string, ttlMs: number): unknown | null {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.fetchedAt < ttlMs) return entry.data;
  return null;
}
function setCache(key: string, data: unknown) {
  cache.set(key, { data, fetchedAt: Date.now() });
}

// GET /api/worldcup/matches
router.get("/worldcup/matches", async (req, res) => {
  if (!API_KEY) {
    return res.status(503).json({
      error: "Football API key not configured",
      setup: "Add FOOTBALL_DATA_API_KEY environment variable (free at football-data.org)",
    });
  }
  try {
    const cacheKey = "matches";
    const ttl = 30_000; // 30 seconds (live data)
    const cached = getCached(cacheKey, ttl);
    if (cached) return res.json(cached);

    const data = await footballFetch("/competitions/WC/matches?limit=100");
    setCache(cacheKey, data);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/worldcup/standings
router.get("/worldcup/standings", async (req, res) => {
  if (!API_KEY) {
    return res.status(503).json({ error: "Football API key not configured" });
  }
  try {
    const cacheKey = "standings";
    const ttl = 120_000; // 2 minutes
    const cached = getCached(cacheKey, ttl);
    if (cached) return res.json(cached);

    const data = await footballFetch("/competitions/WC/standings");
    setCache(cacheKey, data);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/worldcup/matches/:id
router.get("/worldcup/matches/:id", async (req, res) => {
  if (!API_KEY) {
    return res.status(503).json({ error: "Football API key not configured" });
  }
  try {
    const { id } = req.params;
    const cacheKey = `match-${id}`;
    const ttl = 20_000;
    const cached = getCached(cacheKey, ttl);
    if (cached) return res.json(cached);

    const data = await footballFetch(`/matches/${id}`);
    setCache(cacheKey, data);
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/worldcup/votes/:matchId — get vote counts
router.get("/worldcup/votes/:matchId", async (req, res) => {
  const { matchId } = req.params;
  try {
    const rows = await db
      .select({ teamId: votes.teamId, count: sql<number>`count(*)::int` })
      .from(votes)
      .where(eq(votes.matchId, matchId))
      .groupBy(votes.teamId);
    res.json(rows);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/worldcup/votes — cast a vote
router.post("/worldcup/votes", async (req, res) => {
  const { matchId, teamId, voterToken } = req.body;
  if (!matchId || !teamId || !voterToken) {
    return res.status(400).json({ error: "matchId, teamId, voterToken required" });
  }
  try {
    // Upsert: one vote per voter per match
    const existing = await db
      .select()
      .from(votes)
      .where(and(eq(votes.matchId, matchId), eq(votes.voterToken, voterToken)))
      .limit(1);

    if (existing.length > 0) {
      // Update existing vote
      await db
        .update(votes)
        .set({ teamId })
        .where(and(eq(votes.matchId, matchId), eq(votes.voterToken, voterToken)));
    } else {
      await db.insert(votes).values({ matchId, teamId, voterToken });
    }

    const rows = await db
      .select({ teamId: votes.teamId, count: sql<number>`count(*)::int` })
      .from(votes)
      .where(eq(votes.matchId, matchId))
      .groupBy(votes.teamId);

    res.json(rows);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
