import { Router, type IRouter } from "express";
import healthRouter from "./health";
import openaiRouter from "./openai";
import halloweenRouter from "./halloween";

const router: IRouter = Router();

router.use(healthRouter);
router.use(openaiRouter);
router.use(halloweenRouter);

export default router;
