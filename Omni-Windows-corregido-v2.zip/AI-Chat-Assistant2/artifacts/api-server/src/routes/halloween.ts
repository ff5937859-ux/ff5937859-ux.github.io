import { Router, type IRouter } from "express";
import { and, eq, sql } from "drizzle-orm";
import { db, votes } from "@workspace/db";
import {
  GetHalloweenVotesParams,
  GetHalloweenVotesResponse,
  SubmitHalloweenVoteBody,
  SubmitHalloweenVoteResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const POLL_OPTION_IDS: Record<string, readonly string[]> = {
  "halloween-q1": ["q1-witch", "q1-vampire", "q1-ghost", "q1-skeleton"],
  "halloween-q2": ["q2-trick", "q2-treat", "q2-both", "q2-party"],
  "halloween-q3": ["q3-classic", "q3-supernatural", "q3-slasher", "q3-family"],
  "halloween-q4": ["q4-pumpkin", "q4-candy", "q4-both", "q4-neither"],
  "halloween-q5": ["q5-ghost", "q5-vampire", "q5-zombie", "q5-witch"],
  "halloween-q6": ["q6-chocolate", "q6-caramel-apple", "q6-candy-corn", "q6-other"],
};

async function readVoteCounts(questionId: string) {
  const rows = await db
    .select({ optionId: votes.teamId, count: sql<number>`count(*)::int` })
    .from(votes)
    .where(eq(votes.matchId, questionId))
    .groupBy(votes.teamId);

  return rows;
}

router.get("/halloween/votes/:questionId", async (req, res): Promise<void> => {
  const params = GetHalloweenVotesParams.safeParse(req.params);
  if (!params.success || !POLL_OPTION_IDS[params.data.questionId]) {
    res.status(400).json({ error: "Unknown Halloween poll question" });
    return;
  }

  try {
    const rows = await readVoteCounts(params.data.questionId);
    res.json(GetHalloweenVotesResponse.parse(rows));
  } catch (error) {
    req.log.error({ err: error, questionId: params.data.questionId }, "Failed to load Halloween poll votes");
    res.status(500).json({ error: "Unable to load poll votes" });
  }
});

router.post("/halloween/votes", async (req, res): Promise<void> => {
  const body = SubmitHalloweenVoteBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { questionId, optionId, voterToken } = body.data;
  const allowedOptions = POLL_OPTION_IDS[questionId];
  if (!allowedOptions || !allowedOptions.includes(optionId)) {
    res.status(400).json({ error: "Unknown Halloween poll question or option" });
    return;
  }

  try {
    const existing = await db
      .select({ id: votes.id })
      .from(votes)
      .where(and(eq(votes.matchId, questionId), eq(votes.voterToken, voterToken)))
      .limit(1);

    if (existing.length > 0) {
      await db
        .update(votes)
        .set({ teamId: optionId })
        .where(and(eq(votes.matchId, questionId), eq(votes.voterToken, voterToken)));
    } else {
      await db.insert(votes).values({
        matchId: questionId,
        teamId: optionId,
        voterToken,
      });
    }

    const rows = await readVoteCounts(questionId);
    res.json(SubmitHalloweenVoteResponse.parse(rows));
  } catch (error) {
    req.log.error({ err: error, questionId }, "Failed to save Halloween poll vote");
    res.status(500).json({ error: "Unable to save poll vote" });
  }
});

export default router;
