import { Router } from "express";
import { eq, count } from "drizzle-orm";
import { db } from "@workspace/db";
import { conversations, messages } from "@workspace/db";
import { openai } from "@workspace/integrations-openai-ai-server";
import {
  ListOpenaiMessagesParams,
  SendOpenaiMessageParams,
  SendOpenaiMessageBody,
} from "@workspace/api-zod";

const router = Router();

router.get("/conversations/:id/messages", async (req, res) => {
  try {
    const { id } = ListOpenaiMessagesParams.parse({ id: Number(req.params.id) });
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);
    res.json(
      msgs.map((m) => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Failed to list messages");
    res.status(500).json({ error: "Failed to list messages" });
  }
});

router.post("/conversations/:id/messages", async (req, res) => {
  try {
    const { id } = SendOpenaiMessageParams.parse({ id: Number(req.params.id) });
    const body = SendOpenaiMessageBody.parse(req.body);

    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, id));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }

    // Count existing messages to know if this is the first exchange
    const [{ value: existingCount }] = await db
      .select({ value: count() })
      .from(messages)
      .where(eq(messages.conversationId, id));

    const isFirstMessage = Number(existingCount) === 0;

    await db.insert(messages).values({
      conversationId: id,
      role: "user",
      content: body.content,
    });

    const history = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);

    const chatMessages = history.map((m) => ({
      role: m.role as "user" | "assistant" | "system",
      content: m.content,
    }));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    let fullResponse = "";
    const stream = await openai.chat.completions.create({
      model: "gpt-4o",
      max_tokens: 8192,
      messages: [
        {
          role: "system",
          content:
            "You are Omni, a helpful and intelligent AI assistant. You provide clear, accurate, and thoughtful responses. Format code with proper code blocks. Use markdown for structure when helpful.",
        },
        ...chatMessages,
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    await db.insert(messages).values({
      conversationId: id,
      role: "assistant",
      content: fullResponse,
    });

    // Auto-generate a descriptive title after the first exchange
    if (isFirstMessage) {
      try {
        const titleCompletion = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          max_tokens: 20,
          messages: [
            {
              role: "system",
              content:
                "Generate a short, descriptive title (3-6 words) for a conversation that starts with the following user message. Return ONLY the title text, no quotes, no punctuation at the end.",
            },
            { role: "user", content: body.content },
          ],
        });
        const generatedTitle = titleCompletion.choices[0]?.message?.content?.trim();
        if (generatedTitle) {
          await db
            .update(conversations)
            .set({ title: generatedTitle, updatedAt: new Date() })
            .where(eq(conversations.id, id));
          // Send the new title to the client so it can update instantly
          res.write(`data: ${JSON.stringify({ titleUpdate: generatedTitle })}\n\n`);
        }
      } catch (titleErr) {
        req.log.warn({ titleErr }, "Failed to auto-generate title (non-fatal)");
      }
    } else {
      await db
        .update(conversations)
        .set({ updatedAt: new Date() })
        .where(eq(conversations.id, id));
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Failed to send message");
    const e = err as { status?: number; message?: string };
    let detail = e?.message || "Error desconocido";
    if (e?.status === 401) detail = "La clave OPENAI_API_KEY es incorrecta. Revisa el .env y reinicia Start.bat. (" + detail + ")";
    else if (e?.status === 429) detail = "OpenAI rechaza la peticion: sin saldo o limite alcanzado. Anade saldo en platform.openai.com/settings/organization/billing. (" + detail + ")";
    else if (e?.status === 404) detail = "OpenAI no encuentra el modelo para tu cuenta. (" + detail + ")";
    if (!res.headersSent) {
      res.status(500).json({ error: detail });
    } else {
      res.write(`data: ${JSON.stringify({ error: detail })}\n\n`);
      res.end();
    }
  }
});

export default router;
