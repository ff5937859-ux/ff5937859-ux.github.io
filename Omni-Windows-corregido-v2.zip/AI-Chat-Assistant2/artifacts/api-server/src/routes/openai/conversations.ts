import { Router } from "express";
import { eq, ilike, desc } from "drizzle-orm";
import { db } from "@workspace/db";
import { conversations, messages } from "@workspace/db";
import {
  ListOpenaiConversationsResponse,
  CreateOpenaiConversationBody,
  GetOpenaiConversationParams,
  GetOpenaiConversationResponse,
  UpdateOpenaiConversationParams,
  UpdateOpenaiConversationBody,
  DeleteOpenaiConversationParams,
  ToggleFavoriteConversationParams,
  ToggleFavoriteConversationBody,
  SearchOpenaiConversationsQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/conversations", async (req, res) => {
  try {
    const convos = await db
      .select()
      .from(conversations)
      .orderBy(desc(conversations.updatedAt));
    const parsed = ListOpenaiConversationsResponse.parse(
      convos.map((c) => ({
        id: c.id,
        title: c.title,
        isFavorite: c.isFavorite,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      }))
    );
    res.json(parsed);
  } catch (err) {
    req.log.error({ err }, "Failed to list conversations");
    res.status(500).json({ error: "Failed to list conversations" });
  }
});

router.get("/conversations/search", async (req, res) => {
  try {
    const query = SearchOpenaiConversationsQueryParams.parse(req.query);
    const results = await db
      .select()
      .from(conversations)
      .where(ilike(conversations.title, `%${query.q}%`))
      .orderBy(desc(conversations.updatedAt));
    res.json(
      results.map((c) => ({
        id: c.id,
        title: c.title,
        isFavorite: c.isFavorite,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Failed to search conversations");
    res.status(500).json({ error: "Failed to search conversations" });
  }
});

router.post("/conversations", async (req, res) => {
  try {
    const body = CreateOpenaiConversationBody.parse(req.body);
    const [conv] = await db
      .insert(conversations)
      .values({ title: body.title })
      .returning();
    res.status(201).json({
      id: conv.id,
      title: conv.title,
      isFavorite: conv.isFavorite,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to create conversation");
    res.status(500).json({ error: "Failed to create conversation" });
  }
});

router.get("/conversations/:id", async (req, res) => {
  try {
    const { id } = GetOpenaiConversationParams.parse({ id: Number(req.params.id) });
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, id));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);

    const result = GetOpenaiConversationResponse.parse({
      id: conv.id,
      title: conv.title,
      isFavorite: conv.isFavorite,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
      messages: msgs.map((m) => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    });
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to get conversation");
    res.status(500).json({ error: "Failed to get conversation" });
  }
});

router.patch("/conversations/:id", async (req, res) => {
  try {
    const { id } = UpdateOpenaiConversationParams.parse({ id: Number(req.params.id) });
    const body = UpdateOpenaiConversationBody.parse(req.body);
    const [conv] = await db
      .update(conversations)
      .set({ ...(body.title ? { title: body.title } : {}), updatedAt: new Date() })
      .where(eq(conversations.id, id))
      .returning();
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    res.json({
      id: conv.id,
      title: conv.title,
      isFavorite: conv.isFavorite,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to update conversation");
    res.status(500).json({ error: "Failed to update conversation" });
  }
});

router.delete("/conversations/:id", async (req, res) => {
  try {
    const { id } = DeleteOpenaiConversationParams.parse({ id: Number(req.params.id) });
    const deleted = await db
      .delete(conversations)
      .where(eq(conversations.id, id))
      .returning();
    if (!deleted.length) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete conversation");
    res.status(500).json({ error: "Failed to delete conversation" });
  }
});

router.patch("/conversations/:id/favorite", async (req, res) => {
  try {
    const { id } = ToggleFavoriteConversationParams.parse({ id: Number(req.params.id) });
    const body = ToggleFavoriteConversationBody.parse(req.body);
    const [conv] = await db
      .update(conversations)
      .set({ isFavorite: body.isFavorite, updatedAt: new Date() })
      .where(eq(conversations.id, id))
      .returning();
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    res.json({
      id: conv.id,
      title: conv.title,
      isFavorite: conv.isFavorite,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to toggle favorite");
    res.status(500).json({ error: "Failed to toggle favorite" });
  }
});

export default router;
